extends KinematicBody2D

var radius = 10

var ang = null
var motion = Vector2(0,0)
var UP = Vector2(0, -1)

func _ready():
	$AnimationPlayer.play("rocket")
	rotation = ang
	motion = Vector2(cos(ang), sin(ang)) * 500
	$Timer.start(200)

func _physics_process(delta):
	move_and_slide(motion, UP, true)

func _on_Area_body_entered(body):
	$Area.queue_free()
	$Sprite.queue_free()
	$AnimationPlayer.queue_free()
	$trail.emitting = false
	$explosion.emitting = true
	$Timer.start(6)
	
	var tilemap = $Area.get_overlapping_bodies()[0].get_child(0)
	var gpos = global_position
	get_parent().remove_child(self)
	$Area.get_overlapping_bodies()[0].add_child(self)
	global_position = gpos
	
	var pos = position/10
	
	for x in radius*2:
		for y in radius*2:
			if Vector2(x-radius,y-radius).length() < radius:
				tilemap.set_cell(pos.x+ (x-radius) , pos.y+ (y-radius) , -1)


func _on_Timer_timeout():
	queue_free()
