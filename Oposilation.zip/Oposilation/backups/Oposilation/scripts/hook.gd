extends RigidBody2D

var id = null
var tilemap = null

var airborne = true

func _physics_process(delta):
	if airborne:
		rotation_degrees = rad2deg(linear_velocity.angle())
		if len(get_colliding_bodies()) != 0:
			airborne = false
	
	$Viewport/Hook.rotation_degrees = rotation_degrees
	$Texture.rect_rotation = -rotation_degrees
