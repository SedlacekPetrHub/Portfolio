extends KinematicBody2D

export var my_scale = 10
var tilemap = null

var max_scale = 500
var motion = Vector2(0,0)
var UP = Vector2(0, -1)

func _process(delta):
	$Viewport.size = Vector2(1,1) * my_scale
	$Texture.rect_size = Vector2(1,1) * my_scale
	$Texture.rect_position = -Vector2(0.5,0.5) * my_scale
	$Area2D.scale = Vector2(0.01,0.01) * my_scale
	
	$Viewport/lines.scale.x = my_scale/16.6
	$Viewport/lines.scale.y = my_scale/16.6
	
	$Viewport/lines.position.x = my_scale/2
	$Viewport/lines.position.y = my_scale/2

	my_scale *= 1.015
	motion *= 1.011
	modulate.a = (max_scale / my_scale)-1
	if my_scale >= max_scale:
		queue_free()
	move_and_slide(motion, UP, true)
