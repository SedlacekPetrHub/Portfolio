extends KinematicBody2D

var id = null

var tilemap = null
var ui_map = load("res://nodes/tilemap.tscn").instance()
var camera = null
var motion = Vector2(0,0)
var UP = Vector2(0, -1)

var acceleration = 4
var max_speed = 80

var true_motion = Vector2(0,0)
var inputs = [Vector2(0,0)]
var blink_timer:int = 0
var jump_iteration = 0
var ang = Vector2(0,0)
var block_selected = Vector2()
var is_flying = false
var stamina = 100
var is_holding = false
var block_held = -1

func _ready():
	ui_map.tile_set = load("res://assets/tileset.tres")
	get_parent().get_child(0).add_child(ui_map)
	#position = get_parent().spawn * 10
	UP = Vector2(cos(deg2rad(global_rotation_degrees - 90)), sin(deg2rad(global_rotation_degrees - 90)))

func _physics_process(delta):
	action()
	if int($block_sprite.position.y) <= 0:
		movement()
	else:
		motion.x /= 1.2
	ray()
	other()
	face()
	physics()
	
	true_motion = Vector2(motion.x * cos(global_rotation) - motion.y * sin(global_rotation) ,  motion.x * sin(global_rotation) + motion.y * cos(global_rotation))
	move_and_slide(true_motion, UP, true)

func physics():
	if (is_on_floor() and motion.y > 0) or is_on_ceiling():
		motion.y = 0
	motion.y += 12
	if motion.y < 0:
		if is_flying:
			pass
		elif jump_iteration == 0:
			$sprite.frame = 4
		elif jump_iteration == 1:
			$sprite.frame = 1
	
	elif abs(motion.x) <= 0.1:
		motion.x = 0
		$sprite.frame = 0
	
	if motion.y > 1500:
		motion.y = 1500
	elif motion.y < -700:
		motion.y = -700

func movement():
	if ((inputs.has("jump_now") and is_on_floor() == false) or (inputs.has("jump") and is_flying == true and is_on_floor() == false)) and stamina > 0:
		is_flying = true
		stamina -= 1.5
		$anim_move.play("move")
		$anim_move.playback_speed = 3
		$fly_particles.emitting = true
		if motion.y > 0:
			motion.y -= 35
		else:
			motion.y -= 17
	else:
		if stamina < 100 and is_on_floor():
			stamina += 1
		$fly_particles.emitting = false
		$anim_move.playback_speed = 1
		is_flying = false
	
	if inputs.has("jump_now") and is_on_floor(): 
		motion.y = -190
		if jump_iteration == 0:
			jump_iteration = 1
		elif jump_iteration == 1:
			jump_iteration = 0
	
	if is_on_floor() == false and is_flying == false:
		$anim_move.stop()
	
	if (inputs.has("left") and motion.x > 0) or (inputs.has("right") and motion.x < 0):
		motion.x /= 1.1
	if inputs.has("left"):
		$sprite.flip_h = true
		if abs(motion.x) <= max_speed:
			motion.x -= acceleration
		if is_on_floor():
			$anim_move.play("move")
	elif inputs.has("right"):
		$sprite.flip_h = false
		if abs(motion.x) <= max_speed:
			motion.x += acceleration
		if is_on_floor():
			$anim_move.play("move")
	else:
		motion.x /= 1.2

func ray():
	if inputs.has("shoot_now") and stamina >= 50 and is_holding == false:
		stamina -= 50
		var ray = load("res://nodes/ray.tscn").instance()
		ray.position = position
		ray.get_child(0).get_child(0).rotation = inputs[0].angle()
		ray.get_child(2).rotation = inputs[0].angle()
		ray.motion = inputs[0] * 30
		ray.modulate = $sprite.modulate
		ray.tilemap = tilemap
		get_parent().add_child(ray)

func other():
	if inputs.has("zoom_in") and camera.zoom.x >= 0.05:
		camera.zoom *= 0.97
	if inputs.has("zoom_out") and camera.zoom.x <= 10:
		camera.zoom *= 1.03
	
	if is_holding == false:
		block_held = -1
		$block_sprite.visible = false
		$block_box.disabled = true
		ui_map.clear()
		if tilemap.get_cell((block_selected/10).x, (block_selected/10).y) != -1:
			ui_map.set_cell((block_selected/10).x, (block_selected/10).y, 3)
			if inputs.has("grab_now"):
				ui_map.modulate = "ffff00"
				block_held =tilemap.get_cell((block_selected/10).x, (block_selected/10).y)
				tilemap.set_cell((block_selected/10).x, (block_selected/10).y, -1)
				is_holding = true
			else:
				ui_map.modulate = "ffffff"
				is_holding = false
				$block_sprite.position *= 0
				$block_box.position *= 0
	
	elif is_holding == true:
		$block_sprite.frame = block_held
		$block_sprite.visible = true
		$block_box.disabled = false
		ui_map.clear()
		if (tilemap.get_cell((block_selected/10).x, (block_selected/10).y) == -1) and int((block_selected-position).length()) != 0:
			$block_sprite.position = block_selected-position
			$block_box.position = block_selected-position
			ui_map.set_cell((block_selected/10).x, (block_selected/10).y, 3)
			
			if ui_map.get_cell( int(position.x/10),int(position.y/10) ) != -1:
				ui_map.modulate = "ff0000"
				is_holding = true
			elif inputs.has("grab") and (inputs.has("jump_now") == false and len(get_neighbours(tilemap, block_selected/10)) < 3):
				ui_map.modulate = "ffff00"
				is_holding = true
			elif inputs.has("grab") == false or (inputs.has("jump_now") and len(get_neighbours(tilemap, block_selected/10)) >= 3 ):
				ui_map.modulate = "ffffff"
				$block_sprite.position *= 0
				$block_box.position *= 0
				$block_box.disabled = true
				is_holding = false
				if len(get_neighbours(tilemap, block_selected/10)) > 0:
					tilemap.set_cell((block_selected/10).x, (block_selected/10).y, block_held)
				else:
					var fall_block = load("res://nodes/falling_block.tscn").instance()
					fall_block.block_id = 6#block_held
					fall_block.tilemap = tilemap
					fall_block.position = (Vector2(int(block_selected.x/10), int(block_selected.y/10)) * 10) + Vector2(5,5)
					get_parent().add_child(fall_block)
		
		if block_held > 5 and inputs.has("shoot"):
			weapons(block_held)

func face():
	var norm = inputs[0]
	
	norm = Vector2(int(norm.x*1.5), int(norm.y*1.5))
	$eyes.position = norm + Vector2(0, -1)
	$eyes.position.y /= 2
	
	if Vector2(round(norm.x/2), round(norm.y/2)) != Vector2(0,0):
		ang = Vector2(round(norm.x/2), round(norm.y/2))
	block_selected = position + ang*10
	
	$vision_line.cast_to = norm * 60
	
	if stamina <= 0:
		$eyes.frame = 8
	elif stamina < 50:
		$eyes.frame = 3
	elif stamina < 75:
		$eyes.frame = 1
	elif stamina <= 100:
		$eyes.frame = 0
		if $vision_line.is_colliding() == false and norm.y > 0:
			$eyes.frame = 1
	
	blink_timer -= 1
	if blink_timer <= 0:
		$anim_eyes.play("blink")
		blink_timer = rand_range(2,8) * 60

func weapons(wpn):
	ui_map.modulate = "ffffff"
	$block_sprite.position *= 0
	$block_box.position *= 0
	$block_box.disabled = true
	is_holding = false
	
	# aimed missile
	if wpn == 6:
		var rocket = load("res://nodes/weapons/aimed_rocket.tscn").instance()
		rocket.global_position = global_position
		rocket.ang = inputs[0].angle() + global_rotation
		get_parent().get_parent().add_child(rocket)


func action():
	
	var new_input = [Vector2(0,0),Vector2(0,0)]
	
	if id == -1:
		var joy = ((get_global_mouse_position() - global_position).normalized()) * 1.5
		# ANGLE
		new_input[0] = Vector2(cos(joy.angle() - global_rotation),  sin(joy.angle() - global_rotation))
		# AIM
		new_input[1] = joy
		
		if Input.is_action_pressed("left_1"):
			if inputs.has("left") == false:
				new_input.append("left_now")
			new_input.append("left")
		if Input.is_action_pressed("right_1"):
			if inputs.has("right") == false:
				new_input.append("right_now")
			new_input.append("right")
		if Input.is_action_pressed("up_1"):
			if inputs.has("up") == false:
				new_input.append("up_now")
			new_input.append("up")
		if Input.is_action_pressed("down_1"):
			if inputs.has("down") == false:
				new_input.append("down_now")
			new_input.append("down")
		
		if Input.is_action_pressed("jump_1"):
			if inputs.has("jump") == false:
				new_input.append("jump_now")
			new_input.append("jump")
		if Input.is_action_pressed("grab_1"):
			if inputs.has("grab") == false:
				new_input.append("grab_now")
			new_input.append("grab")

		if Input.is_action_pressed("pull_1"):
			if inputs.has("pull") == false:
				new_input.append("pull_now")
			new_input.append("pull")
		if Input.is_action_just_pressed("shoot_1"):
			if inputs.has("shoot") == false:
				new_input.append("shoot_now")
			new_input.append("shoot")

		if Input.is_action_pressed("map_1"):
			if inputs.has("map") == false:
				new_input.append("map_now")
			new_input.append("map")
	
	if id >= 0:
		var joy = Vector2(Input.get_joy_axis(id,0), Input.get_joy_axis(id,1))
		new_input[0] = joy
		new_input[1] = joy
		
		if joy.x < -0.2:
			if inputs.has("left") == false:
				new_input.append("left_now")
			new_input.append("left")
		if joy.x > 0.2:
			if inputs.has("right") == false:
				new_input.append("right_now")
			new_input.append("right")
		if joy.y < -0.2:
			if inputs.has("up") == false:
				new_input.append("up_now")
			new_input.append("up")
		if joy.y > 0.2:
			if inputs.has("down") == false:
				new_input.append("down_now")
			new_input.append("down")
		
		if Input.is_joy_button_pressed(id, 0):
			if inputs.has("jump") == false:
				new_input.append("jump_now")
			new_input.append("jump")
		if Input.is_joy_button_pressed(id, 1):
			if inputs.has("grab") == false:
				new_input.append("grab_now")
			new_input.append("grab")
		if Input.is_joy_button_pressed(id, 3):
			if inputs.has("zoom_in") == false:
				new_input.append("zoom_in_now")
			new_input.append("zoom_in")
		if Input.is_joy_button_pressed(id,2):
			if inputs.has("zoom_out") == false:
				new_input.append("zoom_out_now")
			new_input.append("zoom_out")

		if Input.is_joy_button_pressed(id,4):
			if inputs.has("pull") == false:
				new_input.append("pull_now")
			new_input.append("pull")
		if Input.is_joy_button_pressed(id,5):
			if inputs.has("shoot") == false:
				new_input.append("shoot_now")
			new_input.append("shoot")

		if Input.is_joy_button_pressed(id,11):
			if inputs.has("map") == false:
				new_input.append("map_now")
			new_input.append("map")
	
	inputs = new_input

func _input(event : InputEvent) -> void:
	if event is InputEventMouseButton and id == -1:
		event as InputEventMouseButton
		if event.pressed:
			match event.button_index:
				BUTTON_WHEEL_UP:
					if camera.zoom.x >= 0.05:
						camera.zoom *= 0.9
				BUTTON_WHEEL_DOWN:
					if camera.zoom.x <= 10:
						camera.zoom *= 1.1

func get_neighbours(tilemap, cell:Vector2):
	var neighbours = []
	if tilemap.get_cell(cell.x-1, cell.y) != -1:
		neighbours.append(tilemap.get_cell(cell.x, cell.y))
	if tilemap.get_cell(cell.x+1, cell.y) != -1:
		neighbours.append(tilemap.get_cell(cell.x, cell.y))
	if tilemap.get_cell(cell.x, cell.y-1) != -1:
		neighbours.append(tilemap.get_cell(cell.x, cell.y))
	if tilemap.get_cell(cell.x, cell.y+1) != -1:
		neighbours.append(tilemap.get_cell(cell.x, cell.y))
	return neighbours
