extends KinematicBody2D

var block_id = null
var tilemap = null

var motion = Vector2(0,0)
var UP = Vector2(0, -1)

func _ready():
	$block_sprite.frame = block_id
	UP = Vector2(cos(deg2rad(global_rotation_degrees - 90)), sin(deg2rad(global_rotation_degrees - 90)))

func _physics_process(delta):
	motion += Vector2(cos(global_rotation+PI/2), sin(global_rotation+PI/2)) * 12
	motion = move_and_slide(motion, UP)
	
	if is_on_floor() and block_id != null:

		tilemap.set_cell(int(position.x/10), int(position.y/10), block_id)
		queue_free()
