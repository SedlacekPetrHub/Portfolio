extends KinematicBody2D

var block_id = 6
var tilemap = null

var motion = Vector2(0,0)
var UP = Vector2(0, -1)

func _ready():
	$Sprite.frame = block_id

func _process(delta):
	move_and_slide(motion, UP, true)
	if motion.length() > 60:
		motion /= 1.01
	
	for i in get_slide_count():
		var collision = get_slide_collision(i)
		if i>0:
			motion /= 1.01
		if i < 1 and tilemap != null:
			var fall_block = load("res://nodes/falling_block.tscn").instance()
			fall_block.block_id = block_id
			fall_block.tilemap = tilemap
			tilemap.get_parent().add_child(fall_block)
			fall_block.global_position = (Vector2(int(global_position.x/10), int(global_position.y/10)) * 10)
			fall_block.global_rotation = tilemap.global_rotation
			queue_free()

func _on_Area_area_entered(area):
	motion = -$Area.get_overlapping_areas()[0].get_parent().motion
	tilemap = $Area.get_overlapping_areas()[0].get_parent().tilemap
