extends Camera2D

var target = null

func _process(delta):
	if target:
		global_position = target.global_position
		global_position += -Vector2(cos(global_rotation+PI/2), sin(global_rotation+PI/2)) * 60 * (zoom.y - 0.7)
		global_rotation_degrees = target.get_parent().global_rotation_degrees
		#global_rotation_degrees += (target.motion.x / target.max_speed)
