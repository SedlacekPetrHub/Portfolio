extends StaticBody2D

export var size = Vector2(200,102)
export var cave_ratio = -30

func _ready():
	randomize()
	generate_terrain()

func generate_terrain():
	$terrainmap.clear()
	var height_map = []
	# HILLINESS -----------------------------------------
	var hilliness = OpenSimplexNoise.new()
	hilliness.seed = randi()
	
	hilliness.octaves = 6
	hilliness.period = 20
	
	# HEIGHTMAP -----------------------------------------
	var height = OpenSimplexNoise.new()
	height.seed = randi()
	
	height.period = 40
	height.octaves = 4
	height.lacunarity = 1
	height.persistence = 0
	
	for x in size.x:
		height.period = 15 + (hilliness.get_noise_2d(x, 0))
		
		height_map.append(int(((height.get_noise_2d(x, 0))*10)+size.y/2))
	
	# TERRAIN -------------------------------------------
	var terrain = OpenSimplexNoise.new()
	terrain.seed = randi()
	
	terrain.period = 18
	terrain.octaves = 4
	terrain.lacunarity = 2
	terrain.persistence = 0.3
	
	for x in size.x:
		for y in size.y:
			
			if y >= height_map[x]:
				var lvl:int = (terrain.get_noise_2d(x, y))*100
				
				if lvl >= cave_ratio:
					if y == height_map[x]:
						$terrainmap.set_cell(x,y,0)
					elif y >= height_map[x]/2 + size.y/2:
						$terrainmap.set_cell(x,y,2)
					else:
						$terrainmap.set_cell(x,y,1)
