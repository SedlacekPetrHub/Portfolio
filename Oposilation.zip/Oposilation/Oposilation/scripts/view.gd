extends Node2D

onready var map = $map
var res = Vector2(1920, 1080)

# controller -1 = wasd           controller -2 = ai           controller -3 = online
# player = [num, team, controller, color, hat]
var players = [ [0, 1, -1, "ff0000", 0], [1, 2, -2, "0000ff", 0], [2, 3, -2, "ffff00", 0], [3, 4, -2, "60ff60", 0]   ]#   , [1, 5, -2, "0000ff", 0], [2, 6, -2, "ffff00", 0], [3, 7, -2, "60ff60", 0] ]

var screens = []
var teams = []
var world = null

# READY ===========================
func _ready():
	assemble_teams()
	create_world()
	prepare_effects()

func assemble_teams():
	# team = [num, [players], [ai], [online_players], player_count]
	
	for i in players:
		var found = false
		for u in teams:
			if u[0] == i[1]:
				found = true
				u[4] += 1
				if i[2] == -2:
					u[2].append(i[0])
				elif i[2] == -3:
					u[3].append(i[0])
				else:
					u[1].append(i[0])
		if found == false:
			var my_team = [i[1],[],[],[], 0]
			my_team[4] += 1
			if i[2] == -2:
				my_team[2].append(i[0])
			elif i[2] == -3:
				my_team[3].append(i[0])
			else:
				my_team[1].append(i[0])
			teams.append( my_team )
	
	for i in teams:
		if len(i[1]) != 0:
			screens.append(0)

func create_world():
	for i in teams:
		var container = HBoxContainer.new()
		if i[1] != []:
			$Container.add_child(container)
		
		var level = preload("res://nodes/level.tscn").instance()
		
		var lvl_ang = (360/len(teams)) * teams.find(i)
		level.rotation_degrees = lvl_ang
		level.global_position += -Vector2(cos(deg2rad(lvl_ang)), sin(deg2rad(lvl_ang))) * (level.size.x * 5)
		level.global_position += Vector2(cos(deg2rad(lvl_ang+90)), sin(deg2rad(lvl_ang+90))) * ((len(teams)*len(teams)) * 50)
		
		map.add_child(level)
		
		for u in len(i[1]):
			
			var player = preload("res://nodes/player.tscn").instance()
			player.global_position = Vector2((level.size.x*5)+20*u, 0)
			player.id = players[i[1][u]][2]
			player.tilemap = level.get_child(0)
			player.get_child(0).modulate = players[i[1][u]][3]
			level.add_child(player)
			
			var view = preload("res://nodes/map.tscn").instance()
			container.add_child(view)
			view.get_child(0).size = Vector2(res.x/len(i[1]), res.y/len(screens))
			
			if teams.find(i) != 0 or u != 0:
				view.get_child(0).world_2d = world
			else:
				remove_child(map)
				view.get_child(0).add_child(map)
				world = view.get_child(0).get_world_2d()
			
			view.get_child(0).get_child(0).target = player
			player.camera = view.get_child(0).get_child(0)
			view.get_child(0).get_child(0).current = true
			
			var v_border = preload("res://nodes/border.tscn").instance()
			v_border.scale.x = 0.4
			v_border.scale.y = (res.y/len(screens))/9.9
			v_border.position.x = -2
			v_border.position.y = (res.y/len(screens))/2
			view.add_child(v_border)
		
		for u in len(i[2]):
			
			var player = preload("res://nodes/player.tscn").instance()
			player.global_position = Vector2((level.size.x*5)+20*u, 10)
			player.id = players[i[2][u]][2]
			player.tilemap = level.get_child(0)
			player.get_child(0).modulate = players[i[2][u]][3]
			level.add_child(player)
	
		var h_border = preload("res://nodes/border.tscn").instance()
		h_border.scale.x = res.x
		h_border.scale.y = 0.4
		h_border.position.y = res.y/len(screens) + 1.5
		container.add_child(h_border)

func prepare_effects():
	# BACKGROUND
	map.get_child(2).scale = Vector2(7,7) * len(teams)
	
	# CENTER
	map.get_child(0).scale = Vector2(1,1) * len(teams)
	
	# CLOUDS
	var cloud_ammount = 0#60
	map.get_child(1).scale = Vector2(40,40) * len(teams)
	for i in cloud_ammount:
		var cloud = preload("res://nodes/cloud_maker.tscn").instance()
		
		cloud.amount = rand_range(20, 200)
		cloud.process_material.spread = rand_range(10, 45)
		cloud.modulate.a = rand_range(0.2, 1)
		cloud.speed_scale = rand_range(0.005, 0.03)
		cloud.preprocess = rand_range(0, 350)
		
		cloud.rotation_degrees = (360/cloud_ammount) * i
		map.get_child(1).add_child(cloud)

# PROCESS =========================
func _process(delta):
	ambient_effects()

func ambient_effects():
	# CENTER
	for i in map.get_child(0).get_children():
		var ang = Vector2(i.process_material.direction.x, i.process_material.direction.y).angle() - deg2rad(0.2)
		i.process_material.direction = Vector3(cos(ang), sin(ang), 0)

	# CLOUDS

func _on_item_timer_timeout():
	$item_timer.wait_time = rand_range(0, 10/len(teams))
	var item = load("res://nodes/floating_block.tscn").instance()
	map.add_child(item)
	var item_ang = (360/len(teams)) * int(rand_range(0,len(teams)))   -   (360/len(teams))/2   +   rand_range(-40,40)/len(teams)
	item.rotation_degrees = rand_range(0,360)
	item.motion = -Vector2(cos(deg2rad(item_ang)), sin(deg2rad(item_ang))) * (100)
	item.motion += Vector2(cos(deg2rad(item_ang+90)), sin(deg2rad(item_ang+90))) * ((len(teams)*len(teams))) * ((len(teams)*len(teams)) * 50)
	item.motion = item.motion.normalized() * rand_range(20,60)
