extends Sprite

export var scalable = false
export var distance = 1

export var pos = Vector2(0,0)

var size = Vector2(material.get_shader_param("size_x"), material.get_shader_param("size_y"))

func _ready():
	z_index = -distance

func _process(delta):
	var zoom = stepify(get_viewport().get_child(0).zoom.x, 0.02)

	material.set_shader_param("size_x",1920*(zoom/distance))
	material.set_shader_param("size_y",1080*(zoom/distance))
	
	if scalable:
		scale = Vector2(1,1) * (zoom/distance)
		position = (pos*zoom) + (Vector2(int(get_viewport().get_child(0).position.x), int(get_viewport().get_child(0).get_camera_screen_center().y)))
