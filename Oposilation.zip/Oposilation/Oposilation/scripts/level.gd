extends StaticBody2D

var size = Vector2(200,150)
var cave_ratio = -30

var spawn = Vector2(size.x/2,0)

func _ready():
	randomize()
	generate_terrain()

func generate_terrain():
	$terrainmap.clear()
	var height_map = []
	# HILLINESS -----------------------------------------
	var hilliness = OpenSimplexNoise.new()
	hilliness.seed = randi()
	
	hilliness.octaves = 6
	hilliness.period = 20
	
	# HEIGHTMAP -----------------------------------------
	var height = OpenSimplexNoise.new()
	height.seed = randi()
	
	height.period = 40
	height.octaves = 4
	height.lacunarity = 1
	height.persistence = 0
	
	for x in size.x:
		height.period = 15 + (hilliness.get_noise_2d(x, 0))
		
		height_map.append(int(((height.get_noise_2d(x, 0))*10)+size.y/2))
	
	# TERRAIN -------------------------------------------
	var terrain = OpenSimplexNoise.new()
	terrain.seed = randi()
	
	terrain.period = 18
	terrain.octaves = 4
	terrain.lacunarity = 2
	terrain.persistence = 0.3
	
	for x in size.x:
		for y in size.y:
			
			if y >= height_map[x]:
				terrain.period = (size.x - Vector2(x,y).distance_to(size/2)) / 15
				var lvl:int = (terrain.get_noise_2d(x, y))*100  -  Vector2(x,y).distance_to(size/2)
				
				
				if lvl >= cave_ratio:
					if y == height_map[x]:
						$terrainmap.set_cell(x,y,0)
						if x == size.x/2:
							spawn.y = y
					elif y >= height_map[x]/2 + size.y/2:
						$terrainmap.set_cell(x,y,2)
					else:
						$terrainmap.set_cell(x,y,1)
