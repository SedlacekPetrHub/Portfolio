extends Node2D

@export var radius = 100
var prev_radius = radius
@export var central_body:Node2D = null
var prev_central_body = central_body
@export var SemiMajorAxis = 100
var prev_SemiMajorAxis = SemiMajorAxis
@export_range(0,1) var eccentr:float = 0
var prev_eccentr = eccentr
@export_range(0,360) var eccentr_angle = 0
var prev_eccentr_angle = eccentr_angle
@export var initial_angle = 0.0

var mass = 0.0
var global_velocity
var central_velocity

func _ready():
	update_sprite()

func _process(delta):
	if central_body:
		var time = get_parent().get_parent().time_delta  # use global time
		var G: float = Data.grav_constant
		var mu: float = G * central_body.mass
		var a = SemiMajorAxis
		var n = sqrt(mu / pow(a, 3))  # Mean motion in rad/s

		var M0 = deg_to_rad(initial_angle)  # Initial mean anomaly in radians
		var M = M0 + n * time  # Mean anomaly at time

		var theta = compute_true_anomaly(M, eccentr)  # True anomaly from Kepler's equation
		var angle_deg = rad_to_deg(theta)
		
		position = kepler(central_body.position, SemiMajorAxis, eccentr, eccentr_angle, angle_deg)
	
		$OrbitLine.global_position = central_body.global_position
		debug_draw()
	
	if radius != prev_radius:
		update_sprite()
	
	if central_body != prev_central_body or SemiMajorAxis != prev_SemiMajorAxis or eccentr != prev_eccentr or eccentr_angle != prev_eccentr_angle:
		draworbit()
		prev_central_body = central_body
		prev_SemiMajorAxis = SemiMajorAxis
		prev_eccentr = eccentr
		prev_eccentr_angle = eccentr_angle

func update_sprite():
	$Sprite.polygon = PackedVector2Array()
	var pool = PackedVector2Array()
	for i in 360:
		var point = Vector2(cos(deg_to_rad(i)) * radius, sin(deg_to_rad(i)) * radius)
		pool.append(point)
	$Sprite.polygon = pool
	$Collision.polygon = pool
	prev_radius = radius
	$OrbitLine.width = 0.4 * radius
	prev_radius = radius
	#if mass == null:
		#mass = density * ((4/3)*PI*pow(radius, 3))

func kepler(target, a, e, rot, O):
	var distance = (a * (1 - e * e)) / (1 + e * cos(deg_to_rad(O)))
	var pos = target + (distance * Vector2(cos(deg_to_rad(O)), sin(deg_to_rad(O)))).rotated(deg_to_rad(rot))
	return pos

func draworbit():
	if central_body:
		$OrbitLine.clear_points()
		for i in 361:
			$OrbitLine.add_point(kepler(Vector2(0,0), SemiMajorAxis, eccentr, eccentr_angle, i))

func compute_true_anomaly(M, e):
	var E = M  # Initial guess for eccentric anomaly
	for i in 5:
		E = M + e * sin(E)
	return 2 * atan2(sqrt(1 + e) * sin(E / 2), sqrt(1 - e) * cos(E / 2))


func debug_draw():
	$Label.set_text(name)
	$Label.position.x = radius * 1.2
	var zoom = get_parent().get_parent().get_child(2).get_child(2).get_child(0).zoom
	$Label.scale = Vector2(1,1) / zoom
	$OrbitLine.width = (1 / zoom.x) * 3
