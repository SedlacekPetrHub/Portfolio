extends Node

var grav_constant = 0.00000000006674
