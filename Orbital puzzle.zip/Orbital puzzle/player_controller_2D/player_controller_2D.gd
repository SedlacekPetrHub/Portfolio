extends Node2D

var camera_speed = 20

@onready var camera = $camera_target/Camera
var max_camera_zoom = 4
var min_camera_zoom = 0.01
var camera_target_zoom = 1

var select_O = Vector2.ZERO
var select_E = Vector2.ZERO

var target = null

var last_mouse_pos = Vector2.ZERO

func _process(delta):
	select()
	camera_controls()

func select():
	$selection_box.width = 1/camera.zoom.x
	
	if Input.is_action_just_pressed("lmb"):
		select_O = get_global_mouse_position()
	
	if Input.is_action_pressed("lmb"):
		select_E = get_global_mouse_position()
		
		$selection_box.visible = true
		$selection_box.points[0] = select_O
		$selection_box.points[1] = Vector2(select_E.x, select_O.y)
		$selection_box.points[2] = select_E
		$selection_box.points[3] = Vector2(select_O.x, select_E.y)
		$selection_box.points[4] = select_O
		
		$selection_area/selection_collision.disabled = false
		$selection_area.monitoring = true
		$selection_area.monitorable = true
		
		$selection_area/selection_collision.global_position = (select_O+select_E)/2
		$selection_area/selection_collision.shape.size.x = abs(select_O.x-select_E.x)
		$selection_area/selection_collision.shape.size.y = abs(select_O.y-select_E.y)

	else:
		select_O = Vector2.ZERO
		select_E = Vector2.ZERO

		
		$selection_box.visible = false
		
		$selection_area/selection_collision.disabled = true
		$selection_area.monitoring = false
		$selection_area.monitorable = false

func camera_controls():
	var size = get_viewport_rect().size
	var m_pos = get_viewport().get_mouse_position()
	camera.zoom += Vector2(1,1) * (camera_target_zoom-camera.zoom.x)/20
	
	var relative_speed = camera_speed * 1/camera.zoom.x
	
	camera.position_smoothing_speed = 5
	
	if Input.is_action_just_pressed("mmb"):
		last_mouse_pos = m_pos
	elif Input.is_action_pressed("mmb"):
		$camera_target.global_position = get_global_mouse_position()
	
	print("-------------------------------")
	print(last_mouse_pos)
	print(get_global_mouse_position())
	
	
	if Input.is_action_pressed("w"):
		$camera_target.global_position.y -= relative_speed
	elif Input.is_action_pressed("s"):
		$camera_target.global_position.y += relative_speed
	if Input.is_action_pressed("a"):
		$camera_target.global_position.x -= relative_speed
	elif Input.is_action_pressed("d"):
		$camera_target.global_position.x += relative_speed

func _input(event : InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.pressed:
			match event.button_index:
				MOUSE_BUTTON_WHEEL_UP:
					if camera_target_zoom < max_camera_zoom:
						camera_target_zoom *= 1.1
					if camera_target_zoom > max_camera_zoom:
						camera_target_zoom = max_camera_zoom
				MOUSE_BUTTON_WHEEL_DOWN:
					if camera_target_zoom > min_camera_zoom:
						camera_target_zoom /= 1.1
					if camera_target_zoom < min_camera_zoom:
						camera_target_zoom = min_camera_zoom
