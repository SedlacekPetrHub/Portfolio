extends Node

@export var time_delta = 0.0

var solar_system_data = [
	# [Name, radius, target, semimajor, eccentr, eccentr_angle, init_angle, mass, color]
	["Sun", 124, null, 0, 0, 0, 1.989e20, "FFD700"],  
	["Mercury", 10.9, "Sun", 1158, 0.2056, 77, 3.301e13, "918171"],
	["Venus", 26.9, "Sun", 2164, 0.0067, 131, 4.867e14, "E6C37F"],  
	["Earth", 28.35, "Sun", 2992, 0.0167, 102, 5.972e14, "2E52A3"],  
	["Moon", 7.75, "Earth", 100, 0.0549, 0, 7.348e12, "BFBFBF"],  
	["Mars", 15.1, "Sun", 4558, 0.0934, 336, 6.417e13, "C1440E"],  
	["Phobos", 5, "Mars", 100, 0.0151, 0, 1.0659e6, "6B5E4F"],  
	["Deimos", 3, "Mars", 50, 0.0002, 0, 1.4762e5, "A49789"],  
	["Jupiter", 311.5, "Sun", 15565, 0.0489, 14, 1.898e17, "D9A066"],  
	["Io", 8.1, "Jupiter", 700, 0.0041, 0, 8.9319e12, "E0A14A"],  
	["Europa", 6.95, "Jupiter", 800, 0.009, 0, 4.7998e12, "A7B3C4"],  
	["Ganymede", 11.75, "Jupiter", 1070, 0.0013, 0, 1.4819e13, "8D8477"],  
	["Callisto", 10.75, "Jupiter", 1880, 0.0074, 0, 1.0759e13, "7E7365"],  
	["Saturn", 259.5, "Sun", 28587, 0.0565, 92, 5.683e16, "F4C27E"],  
	["Titan", 11.45, "Saturn", 1220, 0.0288, 0, 1.3452e13, "E1A05A"],  
	["Rhea", 3.4, "Saturn", 700, 0.0012, 0, 2.31e11, "D3D3D3"],  
	["Iapetus", 3.25, "Saturn", 3560, 0.0293, 0, 1.8056e11, "9C7E56"],  
	["Uranus", 113, "Sun", 57413, 0.0464, 170, 8.681e15, "A6E2E9"],  
	["Titania", 3.5, "Uranus", 435, 0.0011, 0, 3.527e11, "B0B0B0"],  
	["Oberon", 3.35, "Uranus", 585, 0.0014, 0, 3.014e11, "8E8E8E"],  
	["Neptune", 109.5, "Sun", 89967, 0.0095, 44, 1.024e16, "3057A3"],  
	["Triton", 6.05, "Neptune", 355, 0.00002, 0, 2.14e12, "C4C8D5"],  
	["Pluto", 5.3, "Sun", 118128, 0.2488, 113, 1.303e12, "D4B9A3"],  
	["Charon", 2.7, "Pluto", 19.5, 0.0002, 0, 1.586e11, "9C8F8F"]  
]

var kerbol_system_data = [
	# [Name, radius, target, semimajor, eccentr, eccentr_angle, init_angle, mass, color]
	["Kerbol", 200, null, 0, 0, 0, 1.7565459e20, "FFD93D"],  
	["Moho", 12, "Kerbol", 5263.2, 0.2, 15, 2.5263618e11, "6C4A36"],
	["Eve", 17, "Kerbol", 9834.6, 0.01, 0, 1.2244124e14, "B95A96"],
	["Gilly", 4, "Eve", 80, 0.55, 10, 1.2420512e7, "BEB29A"],
	["Kerbin", 33, "Kerbol", 13598.4, 0, 0, 5.2915793e13, "4A90E2"],
	["Mun", 10, "Kerbin", 120, 0, 0, 9.7600236e11, "C2C2C2"],
	["Minmus", 5, "Kerbin", 180, 0.04, 6, 2.6457897e11, "9ED6C0"],
	["Duna", 18, "Kerbol", 20726.4, 0.051, 135.5, 4.5154812e12, "C1440E"],
	["Ike", 10.5, "Duna", 85, 0.03, 0, 2.9607698e11, "7B5A4C"],
	["Dres", 14, "Kerbol", 40845.9, 0.145, 280, 3.2191322e12, "BEBEBE"],
	["Jool", 100, "Kerbol", 68773.2, 0.05, 52, 4.2332127e14, "63B25F"],
	["Laythe", 17, "Jool", 150, 0, 0, 2.9397663e13, "3E89C4"],
	["Vall", 15, "Jool", 240, 0, 0, 3.1088028e13, "8FBED6"],
	["Tylo", 30, "Jool", 400, 0, 0, 4.2332127e13, "C2C2C2"],
	["Bop", 8, "Jool", 500, 0.235, 25, 3.7261536e11, "9C8E7F"],
	["Pol", 7, "Jool", 700, 0.171, 15, 1.0813636e11, "EAD898"],
	["Eeloo", 13, "Kerbol", 90111.6, 0.26, 260, 1.1149355e12, "DCE3E8"]
]

var test_system_data = [
	# [Name, radius, target, semimajor, eccentr, eccentr_angle, init_angle, mass, color]
	["Earth", 28.35, "Sun", 2992, 0.0167, 102, 5.972e14, "2E52A3"],  
	["Moon", 7.75, "Earth", 100, 0.5, 0, 7.348e12, "BFBFBF"],
]

func _ready() -> void:
	
	for i in solar_system_data:
		var planet = load("res://Body_2D/Body_2D.tscn").instantiate()
		
		planet.name = i[0]
		planet.radius = i[1]
		planet.central_body = get_child_by_name(i[0],$G_bodies, i[2])
		planet.SemiMajorAxis = i[3]
		planet.eccentr = i[4]
		planet.eccentr_angle = i[5]
		planet.mass = i[6]
		planet.modulate = i[7]
		
		planet.initial_angle = randi_range(0,360)
		
		$G_bodies.add_child(planet)

func get_child_by_name(node_name, node, child_name):
	for i in node.get_children():
		if i.name == child_name:
			return i
	return null

func _physics_process(delta: float) -> void:
	time_delta += 0.005
	pass
