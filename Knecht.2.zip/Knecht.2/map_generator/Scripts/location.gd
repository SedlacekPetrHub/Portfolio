extends Node2D

var N = Vector2(0,-70)
var S = Vector2(0,70)
var NW = Vector2(-75,-35)
var SW = Vector2(-75,35)
var NE = Vector2(75,-35)
var SE = Vector2(75,35)

var base_start = [S,NW,SW]
var base_end = [N,SE,NE]

var directiones = [N,S,NW,SW,NE,SE]

# info = [num, node, points, [intersections]]
# info = [0, node, [points], [(x,y,num)]]
var paths = []

func _ready():
	generate_paths(0,0,[])

func generate_paths(pos,in_cave, list):

	paths = []
	for i in $paths.get_children():
		i.free()
	var exits = [N,S,NW,SW,NE,SE]
	var main_paths = []
	
	var noise = OpenSimplexNoise.new()
	noise.seed = randi()
	
	noise.octaves = 4
	noise.period = 10
	
	var num:int = 0
	
	for p in 1:
		var path = Line2D.new()
		
		var origin = base_start[rand_range(0,len(base_start))]
		path.add_point(origin)
		exits.erase(origin)
		var exit = base_end[base_start.find(origin)]
		exits.erase(exit)
		
		var length = origin.distance_to(exit) / 3
		var last_point = origin
		var add_main_path_counter:int = 2
		for i in length:
			var dir = origin.direction_to(exit)
			var dis = origin.distance_to(exit)
			var offset = Vector2( cos(dir.angle()+PI/2) , sin(dir.angle()+PI/2) ) * noise.get_noise_2d(i,i) * (length/2 - abs(-length/2+i))
			var point = last_point + (dir * (dis /length))
			
			if i >= length/2.5 and i <= length-length/2.5:
				add_main_path_counter -= 1
				if add_main_path_counter == 0:
					add_main_path_counter = 2
					main_paths.append(point + offset)
			path.add_point(point + offset)
			last_point = point
			
		$paths.add_child(path)
		
		var info = [num,path,path.points,[]]
		info[3].append(path.points[0])
		info[3].append(exit)
		num += 1
		paths.append(info)
	
	for e in exits:
		var path = Line2D.new()
		
		path.add_point(e)
		var exit = find_closest(e,main_paths)
		main_paths.erase(exit)
		
		
		var length = e.distance_to(exit) / 3
		var last_point = e
		for i in length:
			var dir = e.direction_to(exit)
			var dis = e.distance_to(exit)
			var offset = Vector2( cos(dir.angle()+PI/2) , sin(dir.angle()+PI/2) ) * noise.get_noise_2d(i,i) * (length/2 - abs(-length/2+i))
			var point = last_point + (dir * (dis /length))
			
			if i >= length/4 and i <= length-length/4:
				main_paths.append(point + offset)
			path.add_point(point + offset)
			last_point = point
		
		path.add_point(exit)
		$paths.add_child(path)
	
		var info = [num,path,path.points,[]]
		
		info[3].append(path.points[0])
		var exit_path = 0
		for p in $paths.get_children():
			for i in p.points:
				if exit == i:
					for u in paths:
						if u[1] == p:
							exit_path = u[0]
							u[3].append(Vector2(poolvector_find(u[2],exit),num))
							info[3].append(Vector2(poolvector_find(u[2],exit),exit_path))
		
		num += 1
		paths.append(info)
	
	# info = [num, node, points, [intersections]]
	list.append(pos)
	list.append(in_cave)
	list.append(paths)

const INT_MAX = 2147483647
func find_closest(pos, array):

	var best_match = null
	var least_diff = INT_MAX

	for number in array:
		
		var diff
		
		if typeof(pos) == 5:
			diff = abs(pos.x - number.x) + abs(pos.y - number.y)
		else:
			diff = abs(pos - number)
		
		if(diff < least_diff):
			best_match = number
			least_diff = diff

	return best_match

static func poolvector_find(poolvector, value):
	for v in len(poolvector):
		if poolvector[v] == value:
			return v
	return -1
