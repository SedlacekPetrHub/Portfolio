extends StaticBody2D

var to_path
var pointer_pos = Vector2(0,-140)

func action():
	Player.player_node.motion *= 0
	Player.player_level_id = to_path.y
	get_tree().current_scene.get_child(1).get_child(0).draw_player()
	if get_tree().current_scene.get_child(0).get_child(0).orientation == 0:
		Player.player_node.global_position.x = get_tree().current_scene.get_child(0).get_child(0).end - 10
		Player.player_node.global_position.y = get_tree().current_scene.get_child(0).get_child(0).get_child(0).map_to_world(Vector2(0,-get_tree().current_scene.get_child(0).get_child(0).heights[-2])).y - 20
	elif get_tree().current_scene.get_child(0).get_child(0).orientation == 1:
		Player.player_node.global_position.x = 10
		Player.player_node.global_position.y = get_tree().current_scene.get_child(0).get_child(0).get_child(0).map_to_world(Vector2(0,-get_tree().current_scene.get_child(0).get_child(0).heights[1])).y - 20
