extends StaticBody2D

var pointer_pos = Vector2(0,-100)

func action():
	if Player.player_in_cave == false:
		Player.player_in_cave = true
	elif Player.player_in_cave == true:
		Player.player_in_cave = false
	get_tree().current_scene.get_child(1).get_child(0).draw_player()
	Player.player_node.global_position.x = get_tree().current_scene.get_child(0).get_child(0).get_child(0).map_to_world( Vector2(get_tree().current_scene.get_child(0).get_child(0).cave_pos,0) ).x
	Player.player_node.global_position.y = get_tree().current_scene.get_child(0).get_child(0).get_child(0).map_to_world(Vector2(0,-get_tree().current_scene.get_child(0).get_child(0).heights[get_tree().current_scene.get_child(0).get_child(0).cave_pos])).y - 20
