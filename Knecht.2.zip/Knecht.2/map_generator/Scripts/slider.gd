extends Polygon2D

var name_offset
var names
var origin
var holding = false
var variable
var multiplier

func _ready():
	global_position.y = origin
	get_child(0).rect_position = Vector2(35,0)
	get_child(1).rect_position = Vector2(-20,100*name_offset)
	get_child(1).text = str(names)

func _process(delta):
	var m = get_global_mouse_position()
	if (m.x >= global_position.x and m.x <= global_position.x + 30 and m.y >= global_position.y and m.y <= global_position.y + 10) and Input.is_action_just_pressed("mouse_1"):
		holding = true
	if Input.is_action_just_released("mouse_1"):
		holding = false
	
	var difference = origin-global_position.y
	get_parent().variables[variable] = difference * multiplier
	get_child(0).text = str(get_parent().variables[variable])
	if holding:
		global_position.y = m.y
