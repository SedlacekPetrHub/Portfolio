extends StaticBody2D

var length_modifier = 20

var base_period = 0
var base_octaves:int = 0
var base_lacunarity = 0

var period_period = 0
var period_octaves:int = 0
var period_lacunarity = 0
var period_strength = 0

var octaves_period = 0
var octaves_octaves:int = 0
var octaves_lacunarity = 0
var octaves_strength = 0

var height_multiplier = 0
var verts = PoolVector2Array()

var noise_seed = randi()
var variables = [0,0,0,0,0,0,0,0,0,0,0,0]

func _ready():
	slider(Vector2(100,120), 1, "base_period", 0, 0.5)           # base_period
	slider(Vector2(200,120), -1, "base_octaves", 1, 0.05)        # base_octaves
	slider(Vector2(300,120), 1, "base_lacunarity", 2, 0.02)      # base_lacunarity
	
	slider(Vector2(400,120), -1, "period_period", 3, 0.5)        # period_period
	slider(Vector2(500,120), 1, "period_octaves", 4, 0.05)       # period_octaves
	slider(Vector2(600,120), -1, "period_lacunarity", 5, 0.02)   # period_lacunarity
	slider(Vector2(700,120), 1, "period_strength", 6, 0.5)       # period_strength
	
	slider(Vector2(800,120), -1, "octaves_period", 7, 0.5)       # octaves_period
	slider(Vector2(900,120), 1, "octaves_octaves", 8, 0.05)      # octaves_octaves
	slider(Vector2(1000,120), -1, "octaves_lacunarity", 9, 0.02) # octaves_lacunarity
	slider(Vector2(1100,120), 1, "octaves_strength", 10, 0.05)   # octaves_strength
	
	slider(Vector2(1200,120), -1, "height_multiplier", 11, 0.2)  # height_multiplier

var last_var
func _process(delta):
	if variables != last_var:
		generate_terrain()
		last_var = variables.duplicate()
	if Input.is_action_just_pressed("ui_accept"):
		print(variables)

func generate_terrain():
	base_period = variables[0]
	base_octaves = variables[1]
	base_lacunarity = variables[2]
	
	period_period = variables[3]
	period_octaves = variables[4]
	period_lacunarity = variables[5]
	period_strength = variables[6]
	
	octaves_period = variables[7]
	octaves_octaves = variables[8]
	octaves_lacunarity = variables[9]
	octaves_strength = variables[10]
	
	height_multiplier = variables[11]
	
	#$pol.polygon.set_polygon()
	verts = PoolVector2Array()
	verts.append(Vector2(0,0))
	
	var period_noise = OpenSimplexNoise.new()
	period_noise.seed = noise_seed
	period_noise.octaves = period_octaves
	period_noise.lacunarity = period_lacunarity
	period_noise.period = period_period
	
	var octaves_noise = OpenSimplexNoise.new()
	octaves_noise.seed = noise_seed
	octaves_noise.octaves = octaves_octaves
	octaves_noise.lacunarity = octaves_lacunarity
	octaves_noise.period = octaves_period
	
	var base_noise = OpenSimplexNoise.new()
	base_noise.seed = noise_seed
	
	var heigths = []
	for i in Player.player_path[5]*length_modifier:
		
		base_noise.period = base_period + period_noise.get_noise_2d(i, -i) * period_strength
		base_noise.octaves = base_octaves + octaves_noise.get_noise_2d(i, -i) * octaves_strength
		base_noise.lacunarity = base_lacunarity
		
		heigths.append(int(20+height_multiplier/2 + base_noise.get_noise_2d(i, -i)*height_multiplier))
	
	for i in Player.player_path[5]*length_modifier:
		
		if i > 3 and heigths[i-1] < heigths[i] and heigths[i-2] <= heigths[i-1]:
			verts.append( Vector2(i-1, -(heigths[i-1])))
		
		if i < Player.player_path[5]*length_modifier-3 and heigths[i+1] < heigths[i] and heigths[i+2] <= heigths[i-1] and heigths[i+3] <= heigths[i-1]:
			verts.append( Vector2(i+1, -(heigths[i+1])))
		
		for u in heigths[i]:
			verts.append( Vector2(i,-u))
		
		if i > 2 and i < Player.player_path[5]*length_modifier-1 and (heigths[i-1] > heigths[i] or heigths[i-2] > heigths[i]) and heigths[i+1] > heigths[i]:
			verts.append( Vector2(i,-heigths[i]))
	
	verts.append(Vector2(0,Player.player_path[5]*length_modifier))
	$pol.polygon = verts
	
func slider(pos,name_offset,name,variable,multiplier):
	var polygon = PoolVector2Array([Vector2(0,0),Vector2(0,10),Vector2(30,10),Vector2(30,0)])
	var flat = PoolVector2Array([Vector2(-3,-100),Vector2(-3,100),Vector2(3,100),Vector2(3,-100)])
	
	var line = Polygon2D.new()
	line.position = pos
	line.position.x += 15
	line.modulate = "000000"
	line.set_polygon(flat)
	add_child(line)
	
	var box = Polygon2D.new()
	box.position = pos
	box.set_polygon(polygon)
	box.add_child(Label.new())
	box.add_child(Label.new())
	box.set_script(load("res://map_generator/Scripts/slider.gd"))
	box.name_offset = name_offset
	box.names = name
	box.variable = variable
	box.multiplier = multiplier
	box.origin = pos.y + 100
	add_child(box)

func change_locale():
	noise_seed = randi()
