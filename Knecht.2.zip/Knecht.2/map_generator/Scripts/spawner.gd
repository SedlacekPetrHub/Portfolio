extends Node2D

export var size = 70

var cave_entrances_number = 100

var land_view_distance = 20
var cave_view_distance = 10

#=====================================================
var temperate = []
#-------------------
var forest = ["Forest", "land_map/tempered/flats/forest", load("res://map_generator/tilemaps/temperate.tres")]
var plains = ["Plains", "land_map/tempered/flats/plains", load("res://map_generator/tilemaps/temperate.tres")]
var ruins = ["Giant ruins", "land_map/tempered/flats/ruins", load("res://map_generator/tilemaps/temperate.tres")]
var peaks = ["Sandstone peaks", "land_map/tempered/hills/peaks", load("res://map_generator/tilemaps/temperate.tres")]
var forested = ["Forested hills", "land_map/tempered/hills/forested", load("res://map_generator/tilemaps/temperate.tres")]
var stalactite = ["Stalactite cavern", "cave_map/stalactite", load("res://map_generator/tilemaps/temperate.tres")]
#-------------------
var temperate_biomes = [[forest,plains,ruins],[peaks,forested],[stalactite]]
var temperate_tileset = load("res://map_generator/tilemaps/temperate.tres")
#=====================================================

var polar = []
#-------------------
var tundra = ["Tundra", "land_map/polar/flats/tundra", load("res://map_generator/tilemaps/polar.tres")]
var taiga = ["Taiga", "land_map/polar/flats/taiga", load("res://map_generator/tilemaps/polar.tres")]
var dragon = ["Dragon's end", "land_map/polar/flats/dragon", load("res://map_generator/tilemaps/polar.tres")]
var glacier = ["Glacier", "land_map/polar/hills/glacier", load("res://map_generator/tilemaps/polar.tres")]
var frozen = ["Frozen cavern", "cave_map/frozen", load("res://map_generator/tilemaps/polar.tres")]
#-------------------
var polar_biomes = [[tundra,taiga,dragon],[glacier],[frozen]]
var polar_tileset = load("res://map_generator/tilemaps/polar.tres")
#=====================================================

var tropical = []
#-------------------
var rainforest = ["Rainforest", "land_map/tropical/flats/rainforest", load("res://map_generator/tilemaps/tropical.tres")]
var savana = ["Savana", "land_map/tropical/flats/savana", load("res://map_generator/tilemaps/tropical.tres")]
var ancient = ["Ancient forest", "land_map/tropical/flats/ancient", load("res://map_generator/tilemaps/tropical.tres")]
var waterfalls = ["Waterfalls", "land_map/tropical/hills/waterfalls", load("res://map_generator/tilemaps/tropical.tres")]
var overgrown = ["Overgrown cavern", "cave_map/overgrown", load("res://map_generator/tilemaps/tropical.tres")]
#-------------------
var tropical_biomes = [[rainforest,savana,ancient],[waterfalls],[overgrown]]
var tropical_tilest = load("res://map_generator/tilemaps/tropical.tres")
#=====================================================

var arid = []
#-------------------
var desert = ["Desert", "land_map/arid/flats/desert", load("res://map_generator/tilemaps/arid.tres")]
var steppe = ["Steppe", "land_map/arid/flats/steppe", load("res://map_generator/tilemaps/arid.tres")]
var rift = ["Rift", "land_map/arid/flats/rift", load("res://map_generator/tilemaps/arid.tres")]
var plateau = ["Plateau", "land_map/arid/hills/plateau", load("res://map_generator/tilemaps/arid.tres")]
var mine = ["Abandoned mine", "cave_map/mine", load("res://map_generator/tilemaps/arid.tres")]
#-------------------
var arid_biomes = [[desert,steppe,rift],[plateau],[mine]]
var arid_tileset = load("res://map_generator/tilemaps/arid.tres")
#=====================================================

var humid = []
#-------------------
var marshland = ["Marshland", "land_map/humid/flats/marshland", load("res://map_generator/tilemaps/humid.tres")]
var swamp = ["Swamp", "land_map/humid/flats/swamp", load("res://map_generator/tilemaps/humid.tres")]
var mushroom = ["Mushroom", "land_map/humid/flats/mushroom", load("res://map_generator/tilemaps/humid.tres")]
var pine = ["Dwarf pine hill", "land_map/humid/hills/pine", load("res://map_generator/tilemaps/humid.tres")]
var swampy = ["Swampy cavern", "cave_map/swampy", load("res://map_generator/tilemaps/humid.tres")]
#-------------------
var humid_biomes = [[marshland,swamp,mushroom],[pine],[swampy]]
var humid_tileset = load("res://map_generator/tilemaps/humid.tres")
#=====================================================

var ocean = []
#-------------------
var cold_sea = ["Cold sea", "ocean_map/cold_sea_map", load("res://map_generator/tilemaps/temperate.tres")]
var polar_sea = ["Polar sea", "ocean_map/polar_sea_map", load("res://map_generator/tilemaps/polar.tres")]
var coral_sea = ["Coral sea", "ocean_map/coral_sea_map", load("res://map_generator/tilemaps/tropical.tres")]
var deep_sea = ["Deep sea", "ocean_map/deep_sea_map", load("res://map_generator/tilemaps/arid.tres")]
var shallow_sea = ["Shallow sea", "ocean_map/shallow_sea_map", load("res://map_generator/tilemaps/humid.tres")]
var flooded = ["Flooded cavern", "cave_map/flooded", load("res://map_generator/tilemaps/temperate.tres")]
#-------------------
var ocean_biomes = [[cold_sea,polar_sea,coral_sea,deep_sea,shallow_sea],[flooded]]
#=====================================================

var zones = [temperate, polar, tropical, arid, humid, ocean]
var all_zone_biomes = [temperate_biomes,polar_biomes,tropical_biomes,arid_biomes,humid_biomes,ocean_biomes]
var zone_names = ["Temperate", "Polar", "Tropical", "Arid", "Humid", "Ocean"]
var all_biomes = [forest,plains,ruins,peaks,forested,stalactite,tundra,taiga,dragon,glacier,frozen,rainforest,savana,ancient,waterfalls,overgrown,desert,steppe,rift,plateau,mine,marshland,swamp,mushroom,pine,swampy,cold_sea,polar_sea,coral_sea,deep_sea,shallow_sea,flooded]
var land_biomes = [forest,plains,ruins,peaks,forested,tundra,taiga,dragon,glacier,rainforest,savana,ancient,waterfalls,desert,steppe,rift,plateau,marshland,swamp,mushroom,pine]
var cave_biomes = [stalactite,frozen,overgrown,mine,swampy,flooded]

var divisor
var taken_zone_map = []
var taken_biome_map = []
var hill_map = []
var height_map = PoolVector3Array()
var land_map = []
var water_map = []
var cave_map = []

var land_paths = []
var cave_paths = []

func _ready():
	
	$cave_map.visible = false
	$cave_fog.visible = false
	$paths/cave_paths.visible = false
	randomize()
	global_position -= Vector2(148*scale.x*size , 140*scale.y*size)/2
	generate_map()
	for i in size:
		for u in size:
			$land_fog.set_cell(i,u,5)
			$cave_fog.set_cell(i,u,5)
	Player.player_coord = (find_closest(Vector2(size/2,size/2),land_map))
	
	calculate_player_vars()
	draw_player()

func _process(delta):
	
	
	
	if Player.menu_map == true:
		$pos/Camera.offset = Vector2(Input.get_joy_axis(0, JOY_AXIS_2), Input.get_joy_axis(0, JOY_AXIS_3)) * 200 * $pos/Camera.zoom.x
		if Input.is_action_pressed("ui_focus_next") and $pos/Camera.zoom.x >= 0.5:
			$pos/Camera.zoom *= 0.985
		elif Input.is_action_pressed("ui_focus_prev") and $pos/Camera.zoom.x <= 10:
			$pos/Camera.zoom *= 1.015
		
		$paths.modulate.a = 2 - ($pos/Camera.zoom.x)/2
		if $paths.modulate.a > 1:
			$paths.modulate.a = 1

func generate_map():
	
	var reset = true
	
	while reset:
		reset = false
		
		taken_zone_map = []
		taken_biome_map = []
		
		temperate = []
		polar = []
		tropical = []
		arid = []
		humid = []
		ocean = []
		
		height_map = []
		land_map = []
		water_map = []
		cave_map = []
		Player.cave_entrances = []
		land_paths = []
		cave_paths = []
		
		for i in $ocean_map.get_children():
			i.clear()
		for r in $land_map.get_children():
			for h in r.get_children():
				for i in h.get_children():
					i.clear()
		for i in $cave_map.get_children():
			i.clear()
		for i in $paths/land_paths.get_children():
			i.free()
		for i in $paths/cave_paths.get_children():
			i.free()
		
		# HILLINESS -----------------------------------------
		var hilliness = OpenSimplexNoise.new()
		hilliness.seed = randi()
		
		hilliness.octaves = 6
		hilliness.period = 20
		
		# HEIGHTMAP -----------------------------------------
		var heightmap = OpenSimplexNoise.new()
		heightmap.seed = randi()
		
		heightmap.octaves = 4
		heightmap.lacunarity = 2
		heightmap.persistence = 0.3
		
		var heights = []
		
		for v in size:
			for h in size:
				
				heightmap.period = 15 + (hilliness.get_noise_2d(v, h))
				
				var height:int = (heightmap.get_noise_2d(v, h))*100
				
				height_map.append(Vector3(h,v,height))
				if height >= 0:
					land_map.append(Vector2(h,v))
				heights.append(height)
		
		var Min = heights.min()
		var Max = heights.max()
		
		divisor = -(Min-Max)/len($ocean_map/cold_sea_map.tile_set.get_tiles_ids())
		
		divide_map(height_map, land_map, 0, 0, 40*(size*0.01), polar, $ocean_map/polar_sea_map)
		divide_map(height_map, land_map, size, size, 40*(size*0.01), tropical, $ocean_map/coral_sea_map)
		divide_map(height_map, land_map, 0, size, 40*(size*0.01), arid, $ocean_map/deep_sea_map)
		divide_map(height_map, land_map, size, 0, 40*(size*0.01), humid, $ocean_map/shallow_sea_map)
		
		for i in height_map:
			if taken_zone_map.has(Vector2(i.x,i.y)) == false:
				if i.z >= 0:
					temperate.append(Vector2(i.x,i.y))
				elif i.z < 0:
					$ocean_map/cold_sea_map.set_cell(i.x,i.y,find_closest( int((i.z / divisor)+10) , $ocean_map/cold_sea_map.tile_set.get_tiles_ids() ))
		
		while len(taken_biome_map) < len(land_map):
			generate_biomes(height_map, polar, polar_biomes[0])
			generate_biomes(height_map, tropical, tropical_biomes[0])
			generate_biomes(height_map, arid, arid_biomes[0])
			generate_biomes(height_map, humid, humid_biomes[0])
			generate_biomes(height_map, temperate, temperate_biomes[0])
		
		for i in hill_map:
			taken_biome_map.erase(i)
		
		while len(taken_biome_map) < len(land_map):
			generate_hills(height_map, polar, polar_biomes[1])
			generate_hills(height_map, tropical, tropical_biomes[1])
			generate_hills(height_map, arid, arid_biomes[1])
			generate_hills(height_map, humid, humid_biomes[1])
			generate_hills(height_map, temperate, temperate_biomes[1])
		
		for i in height_map:
			
			var type = find_closest( int((i.z / divisor)+10) , $ocean_map/cold_sea_map.tile_set.get_tiles_ids() )
			
			if type < 10:
				water_map.append(Vector2(i.x,i.y))
		
		generate_caves()
		
		for i in all_biomes:
			if len(get_node(i[1]).get_used_cells()) == 0:
				reset = true
	
	var used = []
	var true_land = []
	for z in $land_map.get_children():
		for h in z.get_children():
			for i in h.get_children():
				for u in i.get_used_cells():
					if used.has(u) == false:
						used.append(u)
						true_land.append(i.map_to_world(u))
	
	for l in true_land:
		var path = []
		$location.generate_paths(l,false,path)
		draw_paths(l,$paths/land_paths,path)
		var adder = []
		for i in 5:
			adder.append([path[0],path[1],path[2][i][3],path[2][i][0], $paths/land_paths.get_child($paths/land_paths.get_child_count()-1).get_child(path[2][i][0]), len(path[2][i][2]) ])
		land_paths.append(adder)
	
	used = []
	var true_cave = []
	for i in $cave_map.get_children():
		for u in i.get_used_cells():
			if used.has(u) == false:
				used.append(u)
				true_cave.append(i.map_to_world(u))
	
	for l in true_cave:
		var path = []
		$location.generate_paths(l,false,path)
		draw_paths(l,$paths/cave_paths,path)
		var adder = []
		for i in 5:
			adder.append([path[0],path[1],path[2][i][3],path[2][i][0], $paths/cave_paths.get_child($paths/cave_paths.get_child_count()-1).get_child(path[2][i][0]), len(path[2][i][2]) ])
		cave_paths.append(adder)
	
	generate_cave_entrances()
	$location.queue_free()

func divide_map(heightmap, landmap, latitude, longtitude, size, region, sea_type):
	
	var temp_map = PoolVector3Array()
	for i in heightmap:
		temp_map.append(i)
	
	var origin = Vector2(longtitude, latitude)
		
	for i in temp_map:
		if Vector2(i.x,i.y).distance_to(origin) < size-i.z/5 and taken_zone_map.has(Vector2(i.x,i.y)) == false:
			var type = find_closest( int((i.z / divisor)+10) , $ocean_map/cold_sea_map.tile_set.get_tiles_ids() )
			taken_zone_map.append(Vector2(i.x,i.y))
			if i.z >= 0:
				region.append(Vector2(i.x,i.y))
			else:
				ocean.append(Vector2(i.x,i.y))
				sea_type.set_cell(i.x,i.y,find_closest( int((i.z / divisor)+10) , $ocean_map/cold_sea_map.tile_set.get_tiles_ids() ))
func generate_biomes(heightmap, regionmap, biome_type):
	
	var temp_map = PoolVector3Array()
	for i in heightmap:
		if i.z >= 0:
			temp_map.append(i)
	
	var pool = regionmap.duplicate(true)
	for i in taken_biome_map:
		pool.erase(i)
	
	
	if len(pool) != 0:
		var origin = pool[rand_range(0,len(pool))]
		
		var my_biome = biome_type[0]
		biome_type.append(biome_type[0])
		biome_type.remove(0)
		
		var biome = get_node(my_biome[1])
		
		for i in temp_map:
			if i.z >= 43 and Vector2(i.x,i.y).distance_to(origin) < 10-i.z/10 and taken_biome_map.has(Vector2(i.x,i.y)) == false:
				hill_map.append(Vector2(i.x,i.y))
				taken_biome_map.append(Vector2(i.x,i.y))
			
			elif Vector2(i.x,i.y).distance_to(origin) < 10-i.z/10 and taken_biome_map.has(Vector2(i.x,i.y)) == false:
				var type = find_closest( int((i.z / divisor)+10) , my_biome[2].get_tiles_ids() )
				taken_biome_map.append(Vector2(i.x,i.y))
				biome.set_cell(i.x,i.y,type)
func generate_hills(heightmap, regionmap, biome_type):
	
	var temp_map = PoolVector3Array()
	for i in heightmap:
		if i.z >= 0:
			temp_map.append(i)
	
	var pool = regionmap.duplicate(true)
	for i in taken_biome_map:
		pool.erase(i)
	
	if len(pool) != 0:
		var origin = pool[rand_range(0,len(pool))]
		
		var my_biome = biome_type[0]
		biome_type.append(biome_type[0])
		biome_type.remove(0)
		
		var biome = get_node(my_biome[1])
		
		for i in temp_map:
			if Vector2(i.x,i.y).distance_to(origin) < 20 and taken_biome_map.has(Vector2(i.x,i.y)) == false:
				var type = find_closest( int((i.z / divisor)+10) , my_biome[2].get_tiles_ids() )
				taken_biome_map.append(Vector2(i.x,i.y))
				biome.set_cell(i.x,i.y,type)
func generate_caves():
	
	var cave = OpenSimplexNoise.new()
	cave.seed = randi()
	
	cave.period = 20
	
	for v in size:
		for h in size:
			var height = (cave.get_noise_2d(h, v))*100
			if height > -12 and height < 12:
				cave_map.append(Vector2(h,v))
	
	generate_cave_biome($cave_map/frozen, cave_map, polar, polar_tileset, 20, polar_biomes[2])
	generate_cave_biome($cave_map/stalactite, cave_map, temperate, temperate_tileset, 20, temperate_biomes[2])
	generate_cave_biome($cave_map/overgrown, cave_map, tropical, tropical_tilest, 17, tropical_biomes[2])
	generate_cave_biome($cave_map/mine, cave_map, arid, arid_tileset, 17, arid_biomes[2])
	generate_cave_biome($cave_map/swampy, cave_map, humid, humid_tileset, 10, humid_biomes[2])
	generate_cave_biome($cave_map/flooded, cave_map, water_map, load("res://map_generator/tilemaps/temperate.tres"), 9, ocean_biomes[1])
func generate_cave_biome(node, map, region, tileset, tile, biome_type):
	var biome = node
	biome.clear()
	
	for i in map:
		if region.has(i):
			biome.set_cell(i.x,i.y,tile)
func draw_paths(pos, node, list):
	var path_info = list[2]
	
	var cell_paths = Node2D.new()
	node.add_child(cell_paths)
	
	for i in path_info:
		var path = Line2D.new()
		path.default_color = "735308"
		path.width = 3
		path.z_index = 1
		for p in i[2]:
			path.add_point(p + pos + Vector2(100,70))
		cell_paths.add_child(path)

func generate_cave_entrances():
	for i in cave_entrances_number:
		Player.cave_entrances.append(cave_map[rand_range(0,len(cave_map)-1)])

func draw_player():
	Player.player_path[4].self_modulate.b = 1
	calculate_player_vars()
	draw_cave()
	
	if Player.player_in_cave == false:
		for i in $land_fog.get_used_cells():
			if i.distance_to(Player.player_coord) <= land_view_distance:
				$land_fog.set_cell(i.x,i.y,-1)
	elif Player.player_in_cave == true:
		for i in $cave_fog.get_used_cells():
			if i.distance_to(Player.player_coord) <= cave_view_distance:
				$cave_fog.set_cell(i.x,i.y,-1)
	
	if Player.player_in_cave == false:
		for i in len(land_paths):
			$paths/land_paths.get_child(i).modulate.a = 1 - land_paths[i][0][0].distance_to($indicator.map_to_world(Player.player_coord, false)) / 1000
	elif Player.player_in_cave == true:
		for i in len(cave_paths):
			$paths/cave_paths.get_child(i).modulate.a = 1 - cave_paths[i][0][0].distance_to($indicator.map_to_world(Player.player_coord, false)) / 1000
	
	Player.player_path[4].self_modulate.b = 100
	get_tree().current_scene.get_child(0).get_child(0).change_locale()
	
	if Player.player_in_cave == false:
		get_tree().current_scene.get_child(0).get_child(0).get_child(0).modulate = "268d00"
		VisualServer.set_default_clear_color("5a92ff")
	elif Player.player_in_cave == true:
		get_tree().current_scene.get_child(0).get_child(0).get_child(0).modulate = "4f4f4f"
		VisualServer.set_default_clear_color("887a55")
func draw_cave():
	if Player.player_in_cave == false:
		$ocean_map.visible = true
		$land_map.visible = true
		$land_fog.visible = true
		$paths/land_paths.visible = true
		$cave_map.visible = false
		$cave_fog.visible = false
		$paths/cave_paths.visible = false
	elif Player.player_in_cave == true:
		$ocean_map.visible = false
		$land_map.visible = false
		$land_fog.visible = false
		$paths/land_paths.visible = false
		$cave_map.visible = true
		$cave_fog.visible = true
		$paths/cave_paths.visible = true
func calculate_player_vars():
	
	for i in all_biomes:
		if Player.player_in_cave == false and cave_biomes.has(i):
			continue
		elif Player.player_in_cave == true and land_biomes.has(i):
			continue
		if get_node(i[1]).get_used_cells().has(Player.player_coord+Vector2(0,-1)):
			Player.north_cell = i
			for u in height_map:
				if Vector2(u.x,u.y) == Player.player_coord+Vector2(0,-1):
					Player.north_cell[-1] = u.z
		if get_node(i[1]).get_used_cells().has(Player.player_coord):
			Player.player_biome = i
	
	for i in len(all_zone_biomes):
		for u in all_zone_biomes[i]:
			if u.has(Player.player_biome):
				Player.player_zone = zone_names[i]
	
	for i in height_map:
		if Vector2(i.x,i.y) == Player.player_coord:
			Player.player_height = i.z
	
	
	Player.neighbour_cells = []
	var from = [Vector2(0,-70),Vector2(0,70),Vector2(-75,-35),Vector2(-75,35),Vector2(75,-35),Vector2(75,35)]
	var to = []
	var dest = [Vector2(0,70),Vector2(0,-70),Vector2(75,35),Vector2(75,-35),Vector2(-75,35),Vector2(-75,-35)]
	if int(Player.player_coord.x) % 2 == 0 or int(Player.player_coord.x) == 0:
		to = [Vector2(0,-1),Vector2(0,1),Vector2(-1,-1),Vector2(-1,0),Vector2(1,-1),Vector2(1,0)]
	elif int(Player.player_coord.x) % 2 == 1:
		to = [Vector2(0,-1),Vector2(0,1),Vector2(-1,0),Vector2(-1,1),Vector2(1,0),Vector2(1,1)]
	
	if Player.player_in_cave == false:
		for i in land_paths:
			if i[0][0] == $indicator.map_to_world(Player.player_coord, false) and i[Player.player_level_id][3] == Player.player_level_id:
				Player.player_path = i[Player.player_level_id]
				break
		
		var adder = []
		for u in from:
			if Vector2(Player.player_path[2][0].x,Player.player_path[2][0].y) == u or Vector2(Player.player_path[2][1].x,Player.player_path[2][1].y) == u:
				for i in height_map:
					if Vector2(i.x,i.y) == Player.player_coord+to[from.find(u)]:
						var this_path
						for n in land_paths:
							if n[0][0] == $indicator.map_to_world(Player.player_coord+to[from.find(u)], false):
								for p in n:
									if p[2].has(dest[from.find(u)]):
										this_path = p[3]
						adder = [Player.player_coord+to[from.find(u)], this_path, i.z]
				Player.neighbour_cells.append(adder)
	
	elif Player.player_in_cave == true:
		for i in cave_paths:
			if i[0][0] == $indicator.map_to_world(Player.player_coord, false) and i[Player.player_level_id][3] == Player.player_level_id:
				Player.player_path = i[Player.player_level_id]
		
		var adder = []
		for u in from:
			if Vector2(Player.player_path[2][0].x,Player.player_path[2][0].y) == u or Vector2(Player.player_path[2][1].x,Player.player_path[2][1].y) == u:
				for i in height_map:
					if Vector2(i.x,i.y) == Player.player_coord+to[from.find(u)]:
						var this_path
						for n in cave_paths:
							if n[0][0] == $indicator.map_to_world(Player.player_coord+to[from.find(u)], false):
								for p in n:
									if p[2].has(dest[from.find(u)]):
										this_path = p[3]
						adder = [Player.player_coord+to[from.find(u)], this_path, i.z]
				Player.neighbour_cells.append(adder)
	
	if len(Player.neighbour_cells) > 1 and Player.neighbour_cells[0][0].y < Player.neighbour_cells[1][0].y:
		Player.neighbour_cells.append(Player.neighbour_cells[0])
		Player.neighbour_cells.remove(0)
	
	if len(Player.neighbour_cells) > 1 and Player.neighbour_cells[0][0].x > Player.neighbour_cells[1][0].x:
		Player.neighbour_cells.append(Player.neighbour_cells[0])
		Player.neighbour_cells.remove(0)


	#print()
	#print("player_coord  :",Player.player_coord)
	#print("player_in_cave  :",Player.player_in_cave)
	#print("player_zone  :",Player.player_zone)
	#print("player_biome  :",Player.player_biome)
	#print("player_height  :",Player.player_height)
	#print("player_level_id  :",Player.player_level_id)
	#print("player_path  :",Player.player_path)
	#print("neighbour_cells  :",Player.neighbour_cells)
	#print("north_cell  :",Player.north_cell)


const INT_MAX = 2147483647
func find_closest(pos, array):

	var best_match = null
	var least_diff = INT_MAX

	for number in array:
		
		var diff
		
		if typeof(pos) == 5:
			diff = abs(pos.x - number.x) + abs(pos.y - number.y)
		else:
			diff = abs(pos - number)
		
		if(diff < least_diff):
			best_match = number
			least_diff = diff

	return best_match
