extends StaticBody2D

var length_modifier = 20

var base_period = 0
var base_octaves:int = 0
var base_lacunarity = 0

var period_period = 0
var period_octaves:int = 0
var period_lacunarity = 0
var period_strength = 0

var octaves_period = 0
var octaves_octaves:int = 0
var octaves_lacunarity = 0
var octaves_strength = 0

var height_multiplier = 0

var noise_seed = randi()
var variables = [0,0,0,0,0,0,0,0,0,0,0,0]

var orientation = 0
var end
var heights
var buffer
var cave_pos:int = -1

func _ready():
	variables = [60, 5.55, 0.22, 0, 0, 0, 0, 0, 0, 0, 0, 12.4]
	pass

func _process(delta):
	show_player_on_map()
	if (Player.player_node.global_position.x < 0 and orientation == 0) or (Player.player_node.global_position.x > end and orientation == 1):
		var wrong = false
		if len(Player.neighbour_cells) == 1 and orientation == 1:
			wrong = true
		Player.player_coord = Player.neighbour_cells[0][0]
		Player.player_level_id = Player.neighbour_cells[0][1]
		get_tree().current_scene.get_child(1).get_child(0).draw_player()
		Player.player_node.global_position = Vector2(end-10, $TileMap.map_to_world(Vector2(0,-heights[-2]),false).y - 10)
		if wrong == true:
			Player.player_node.global_position = Vector2(10,$TileMap.map_to_world(Vector2(0,-heights[1]),false).y - 10)
		
	elif (Player.player_node.global_position.x > end and orientation == 0) or (Player.player_node.global_position.x < 0 and orientation == 1):
		if len(Player.neighbour_cells) > 1:
			Player.player_coord = Player.neighbour_cells[1][0]
			Player.player_level_id = Player.neighbour_cells[1][1]
			get_tree().current_scene.get_child(1).get_child(0).draw_player()
			Player.player_node.global_position = Vector2(10,$TileMap.map_to_world(Vector2(0,-heights[1]),false).y - 10)
		else:
			Player.player_node.motion *= 0
			var target = Player.player_path[2][1][0]
			Player.player_level_id = Player.player_path[2][1][1]
			get_tree().current_scene.get_child(1).get_child(0).draw_player()
			if orientation == 0:
				Player.player_node.global_position = Vector2($TileMap.map_to_world(Vector2(target,0),false).x * length_modifier, $TileMap.map_to_world(Vector2(0,-heights[target*length_modifier])).y -10)
			if orientation == 1:
				Player.player_node.global_position = Vector2($TileMap.map_to_world(Vector2(Player.player_path[5] - target,0),false).x * length_modifier, $TileMap.map_to_world(Vector2(0,-heights[(Player.player_path[5] - target)*length_modifier])).y -10)


func generate_terrain():
	
	cave_pos = -1
	noise_seed = randi()
	
	base_period = variables[0]
	base_octaves = variables[1]
	base_lacunarity = variables[2]
	
	period_period = variables[3]
	period_octaves = variables[4]
	period_lacunarity = variables[5]
	period_strength = variables[6]
	
	octaves_period = variables[7]
	octaves_octaves = variables[8]
	octaves_lacunarity = variables[9]
	octaves_strength = variables[10]
	
	height_multiplier = variables[11]
	
	var period_noise = OpenSimplexNoise.new()
	period_noise.seed = noise_seed
	period_noise.octaves = period_octaves
	period_noise.lacunarity = period_lacunarity
	period_noise.period = period_period
	
	var octaves_noise = OpenSimplexNoise.new()
	octaves_noise.seed = noise_seed
	octaves_noise.octaves = octaves_octaves
	octaves_noise.lacunarity = octaves_lacunarity
	octaves_noise.period = octaves_period
	
	var base_noise = OpenSimplexNoise.new()
	base_noise.seed = noise_seed
	
	heights = []
	
	var height_diff = 0
	if Player.player_in_cave == false:
		if len(Player.neighbour_cells) > 1:
			height_diff = Player.neighbour_cells[0][2] - Player.neighbour_cells[1][2]
		elif len(Player.neighbour_cells) == 1:
			if orientation == 1:
				height_diff = Player.player_height - Player.neighbour_cells[0][2]
			else:
				height_diff = Player.neighbour_cells[0][2] - Player.player_height
		
		height_diff /= Player.player_path[5]*length_modifier
		height_diff *= -3
	
	for i in Player.player_path[5]*length_modifier:
		
		base_noise.period = base_period + period_noise.get_noise_2d(i, -i) * period_strength
		base_noise.octaves = base_octaves + octaves_noise.get_noise_2d(i, -i) * octaves_strength
		base_noise.lacunarity = base_lacunarity
		
		buffer = (20+height_multiplier/2) + abs(height_diff*Player.player_path[5]*length_modifier)
		
		heights.append(int(buffer + height_diff*i + base_noise.get_noise_2d(i, -i)*height_multiplier))
	
	if Player.cave_entrances.has(Player.player_coord) and Player.player_level_id == 4:
		cave_pos = int(rand_range(10,Player.player_path[5]*length_modifier-10))

func build_terrain():
	for i in $exits.get_children():
		i.queue_free()
	$TileMap.clear()
	
	for i in Player.player_path[5]*length_modifier:
		if i > 1 and heights[i-1] < heights[i] and heights[i-2] <= heights[i-1]:
			$TileMap.set_cell(i-1, -(heights[i-1]), 1)
		elif i == 1 and heights[i-1] < heights[i]:
			$TileMap.set_cell(i-1, -(heights[i-1]), 1)
		
		if i < Player.player_path[5]*length_modifier-3 and heights[i+1] < heights[i] and heights[i+2] <= heights[i-1] and heights[i+3] <= heights[i-1]:
			$TileMap.set_cell(i+1, -(heights[i+1]), 2)
		elif i == Player.player_path[5]*length_modifier-2 and heights[i+1] < heights[i]:
			$TileMap.set_cell(i+1, -(heights[i+1]), 2)
		
		for u in heights[i]:
			$TileMap.set_cell(i,-u,0)
		
		if i > 2 and i < Player.player_path[5]*length_modifier-1 and (heights[i-1] > heights[i] or heights[i-2] > heights[i]) and heights[i+1] > heights[i]:
			$TileMap.set_cell(i,-heights[i],0)
		
	end = $TileMap.map_to_world($TileMap.get_used_cells()[-1]).x
	
	
	if Player.neighbour_cells[0][2] <= -1:
		# add water background
		pass
	
	
	if len(Player.player_path[2]) > 2:
		for i in len(Player.player_path[2])-2:
			var exit = load("res://map_generator/Nodes/path_exit.tscn").instance()
			exit.to_path = Player.player_path[2][i+2]
			if orientation == 0:
				exit.position.x = $TileMap.map_to_world( Vector2(Player.player_path[2][i+2].x*length_modifier, 0)).x
				exit.position.y = get_true_height(Player.player_path[2][i+2].x)
			elif orientation == 1:
				exit.position.x = $TileMap.map_to_world( Vector2((Player.player_path[5] - Player.player_path[2][i+2].x)*length_modifier, 0)).x
				exit.position.y = get_true_height(Player.player_path[5] - Player.player_path[2][i+2].x)
			
			$exits.add_child(exit)
	
	if cave_pos != -1:
		var entrance = load("res://map_generator/Nodes/cave_entrance.tscn").instance()
		entrance.position.x = $TileMap.map_to_world( Vector2(cave_pos, 0)).x
		entrance.position.y = get_true_height(cave_pos/length_modifier)
		$exits.add_child(entrance)

func change_locale():
	orientation = 0
	if len(Player.neighbour_cells) == 1 and [Vector2(0,70),Vector2(-75,-35),Vector2(-75,35)].has(Player.player_path[2][0]) == false:
		orientation = 1
	
	heights = []
	
	if Player.player_in_cave == false:
		if Player.explored_land_pos.has(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id)) == false:
			generate_terrain()
			Player.explored_land_pos.append(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id))
			if cave_pos == -1:
				Player.explored_land_data.append([heights, -1])
			else:
				Player.explored_land_data.append([heights, cave_pos])
			build_terrain()
		else:
			heights = Player.explored_land_data[Player.explored_land_pos.find(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id))][0]
			cave_pos = Player.explored_land_data[Player.explored_land_pos.find(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id))][1]
			build_terrain()
	
	elif Player.player_in_cave == true:
		if Player.explored_cave_pos.has(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id)) == false:
			generate_terrain()
			Player.explored_cave_pos.append(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id))
			if cave_pos == -1:
				Player.explored_cave_data.append([heights, -1])
			else:
				Player.explored_cave_data.append([heights, cave_pos])
			build_terrain()
		else:
			heights = Player.explored_cave_data[Player.explored_cave_pos.find(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id))][0]
			cave_pos = Player.explored_cave_data[Player.explored_cave_pos.find(Vector3(Player.player_coord.x,Player.player_coord.y, Player.player_level_id))][1]
			build_terrain()

func get_true_height(pos:int):
	return $TileMap.map_to_world(Vector2(0,-heights[pos*length_modifier])).y

func sum_array(array):
	var sum:int
	for i in array:
		sum += i
	return sum

func show_player_on_map():
	
	if typeof(Player.player_path[4]) != 2:
		var pos = int((Player.player_node.global_position.x / end) * Player.player_path[5])
		if pos > 0 and pos < len(Player.player_path[4].points):
			if orientation == 1:
				pos = -pos
				if pos >= 0:
					pos = -1
			get_tree().current_scene.get_child(1).get_child(0).get_child(7).position = Player.player_path[4].points[pos]
