extends KinematicBody2D

var acceleration = 30
var air_control = 20
var stopping_force = 40
var max_speed = 700
var jump_force = 1000
var evade_dist = 200

# ===========================

var is_evading = false
var evade_timer

var UP = Vector2(0, -1)
var motion = Vector2()

func _ready():
	Player.player_node = self
	evade_timer = Timer.new()
	evade_timer.set_wait_time(1)
	evade_timer.set_one_shot(true)
	self.add_child(evade_timer)
	
	stopping_force *= 0.01
	stopping_force += 1

func _physics_process(delta):
	
	falling()
	interact()
	menuing()
	
	if is_evading == false:
		movement()
	if Input.is_action_just_pressed("crouch") and is_on_floor():
		crouch()
	if Input.is_action_just_pressed("evade") and is_on_floor():
		evade()
	if Input.is_action_pressed("jump") and is_on_floor():
		jump()
	
	#if Player.in_menu == true and is_on_floor():
		#motion *= 0
		
	motion = move_and_slide(motion, UP)

func falling():
	if is_on_floor() == false:
		motion.y += Physics.gravity

func jump():
	motion.y -= jump_force

func movement():
	#var direction = Vector2(Input.get_joy_axis(0, JOY_AXIS_0), Input.get_joy_axis(0, JOY_AXIS_1))
	var direction = Input.get_vector("ui_left","ui_right", "ui_up","ui_down")
	
	if abs(direction.x) < 0.1:
		direction.x = 0
	
	var force = direction.x
	
	if is_on_floor():
		force *= acceleration
	else:
		force *= air_control
	motion.x += force
	
	if force == 0:
		motion.x /= stopping_force
	
	if abs(motion.x) > max_speed:
		motion.x = max_speed * (motion.x/abs(motion.x))

func crouch():
	pass

func evade():
	is_evading = true
	evade_timer.start()
	if evade_timer.get_time_left() > 0:
		motion.x == max_speed * 2
	is_evading = false

func interact():
	var interaction_objects = []
	var objects_pos = []
	for i in $Area.get_overlapping_areas():
		if i.get_parent().has_method("action"):
			objects_pos.append(i.get_parent().global_position)
			interaction_objects.append(i.get_parent())
	
	if len(interaction_objects) > 0:
		var closest = interaction_objects[objects_pos.find((find_closest(global_position,objects_pos)))]
		$pointer.visible = true
		$pointer.global_position = closest.global_position + closest.pointer_pos
		if Input.is_action_just_pressed("interact"):
			closest.action()
	else:
		$pointer.visible = false

func menuing():
	if Input.is_action_just_pressed("ui_select"):
		if Player.menu_map == true:
			get_tree().current_scene.get_child(1).get_child(0).visible = false
			get_tree().current_scene.get_child(0).visible = true
			$Camera.current = true
			Player.menu_map = false
			Player.in_menu = false
		elif Player.menu_map == false:
			get_tree().current_scene.get_child(1).get_child(0).visible = true
			get_tree().current_scene.get_child(0).visible = false
			get_tree().current_scene.get_child(1).get_child(0).get_child(7).get_child(0).current = true
			Player.menu_map = true
			Player.in_menu = true


const INT_MAX = 2147483647
func find_closest(pos, array):

	var best_match = null
	var least_diff = INT_MAX

	for number in array:
		
		var diff
		
		if typeof(pos) == 5:
			diff = abs(pos.x - number.x) + abs(pos.y - number.y)
		else:
			diff = abs(pos - number)
		
		if(diff < least_diff):
			best_match = number
			least_diff = diff

	return best_match
