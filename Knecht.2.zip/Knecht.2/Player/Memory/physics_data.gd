extends Node2D

var gravity = 80
