extends Node2D

var player_node

var in_menu = false
var player_coord = Vector2(35,35)
var player_in_cave = false

var player_zone
var player_biome
var player_height
var player_level_id = 1
var player_path = [0,0,[0],0,0,20]# [pos, in_cave, intersections, id, node, length]
var neighbour_cells = []# [pos, id, height]
var north_cell = []

var menu_map = false

var explored_land_pos = []
var explored_land_data = [] # [[heights],(cave_pos,cave_id)]

var explored_cave_pos = []
var explored_cave_data = [] # [[heights], cave_pos]

var cave_entrances = []
