extends Node

# [name,icon, rarity%,  lowest_height,highest_height,  lowest_temp,highest_temp,  lowest_biome,highest_biome]

var wood = ["Wood",0, 0.05, 100,2000, -15,29, 0.2,0.8]
var sand = ["Sand",1, 0.05, 0,2500, 30,50, 0.95,1]
var clay = ["Clay",2, 0.03, 100,700, 0,20, 0.4,0.6]
var stone = ["Stone",3, 0.1, 1000, 6000, -50,50, 0,0.8]
var iron = ["Iron",4, 0.06, 800,6000, -40,25, 0,0.7]
var lead = ["Lead",5, 0.06, 800,3000, -10,25, 0.3,0.6]
var oil = ["Oil",6, 0.02, 0,2500, 30,50, 0.95,1]
var coal = ["Coal",7, 0.02, 300,4000, -30,25, 0.1,0.3]
var gold = ["Gold",8, 0.03, 200,8000, 30,50, 0.65,0.95]
var diamonds = ["Diamonds",9 ,0.0015, 0,8000, -50,50, 0,1]

var material_stats = [wood, sand, clay, stone, iron, lead, oil, coal, gold, diamonds]

var material_coords = PackedVector3Array()
