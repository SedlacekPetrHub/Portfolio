extends Node

# [name,icon, position,resources]
var towns = []

var map_on = false
var in_city = true

var flying = false
var landing = false
var landed = true
var rising = false


# Level stats
var gravity = 8
var secconds_per_point = 6    # secconds per point
var curr_level = null
var player_progress = 0

# Map stats
var player_position = null
