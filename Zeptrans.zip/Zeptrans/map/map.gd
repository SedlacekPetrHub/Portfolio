extends Node2D

var material_stats = Materials.material_stats.duplicate()
var material_coords = PackedVector3Array()
var towns = Stats.towns
var town_names = Names.towns.duplicate()

var count = [0,0,0,0,0,0,0,0,0,0]

var world_seed = null

var done_calculating = false
var highhest:int = 0
var highest_coord = Vector2()
var coldest:int = 0
var coldest_coord = Vector2()
var hotest:int = 0
var hotest_coord = Vector2()

var ideal_start_distance = 50
var min_city_distance = 25
var max_city_distance = 100

var camera_speed = 12
var max_camera_zoom = 30
var min_camera_zoom = 3.6
var text_scale = 3
var icon_scale = 3

var create_labels = false
var is_writing = false
var click_pos = Vector2.ZERO
var txt = ""
var labels = null
var camera_target_zoom = 3.6
var camera_target_pos = Vector2.ZERO

var player = Node2D.new()
var target = Node2D.new()

@onready var map_node = $Node
var offset = Vector2.ZERO
@onready var camera = $Camera2D
@onready var cursor = $Node/cursors

func _ready():
	world_seed = randi()
	seed(world_seed)
	town_names.shuffle()
	$Node/map/hills.texture.diffuse_texture.noise.seed = world_seed
	$Node/map/biomes.texture.noise.seed = world_seed+1
	$Node/map/ocean.texture.diffuse_texture.noise.seed = world_seed+2
	$Node/map/clouds.texture.noise.seed = world_seed+3
	
	var rpos = Vector2(0, 0)
	
	player.name = "Player"
	$Node/Icons/pilots.add_child(player)
	
	for I_X in 2:
		for I_Y in 2:
			var icn =  $PilotIcon.duplicate()
			player.add_child(icn)
			icn.global_position = rpos + Vector2(1000*I_X, 700*I_Y)
			icn.global_position += Vector2(0.5,0.5)

	target.name = "target"
	$Node/Icons/pilots.add_child(target)
	target.visible = false
	
	for I_X in 3:
		for I_Y in 3:
			var icn =  $PilotIcon.duplicate()
			icn.frame = 0
			target.add_child(icn)
			icn.global_position = rpos + Vector2(1000*I_X, 700*I_Y)
			icn.global_position += Vector2(0.5,0.5)

func post_ready():
	material_stats = Materials.material_stats.duplicate()
	material_coords = PackedVector3Array()
	count = [0,0,0,0,0,0,0,0,0,0]
	towns.clear()
	for i in $Node/Icons/resource.get_children():
		i.free()
	for i in $Node/Labels.get_children():
		i.free()
	
	for x in 1000:
		for y in 700:
			var m_pos = Vector2(x,y)
			var height = $Node/map/ocean_heights.texture.get_image().get_pixelv(m_pos).r*0.2
			if height > 0 and $Node/map/ocean_heights.texture.get_image().get_pixelv(m_pos).r > 0:
				height += $Node/map/hills_heights.texture.get_image().get_pixelv(m_pos).r
			height *= 8000
			
			var temperature = $Node/map/temperature.texture.get_image().get_pixelv(m_pos).r - 0.4
			temperature *= 70
			temperature -= height/300
			
			find_extremes(x,y, height, temperature)
			spawn_materials(x,y, height,temperature)
	
	if count.has(0) == false and count.has(1) == false and count.has(2) == false:
		spawn_starting_cities()
		show_discovered()
		Stats.player_position = Stats.towns[2][2]
		done_calculating = true
	else:
		print("RESET")

func find_extremes(x,y, height,temperature):
	if height > highhest:
		highhest = int(height)
		highest_coord = Vector2(x,y)
	
	if temperature < coldest and height > 0:
		coldest = temperature
		coldest_coord = Vector2(x,y)
	if temperature > hotest and height > 0:
		hotest = int(temperature)
		hotest_coord = Vector2(x,y)

func spawn_materials(x,y, height,temperature):
	for i in material_stats:
		# [name,icon, rarity%,  lowest_height,highest_height,  lowest_temp,highest_temp,  lowest_biome,highest_biome]
		if (height > i[3] and height < i[4]) and (temperature > i[5] and temperature < i[6]) and (randf_range(0,100) <= i[2]):
			var rpos = Vector2(x, y)
			
			var icon_node = Node2D.new()
			$Node/Icons/resource.add_child(icon_node)
			
			count[i[1]] += 1
			material_coords.append(Vector3(x,y,i[1]))
			
			for I_X in 2:
				for I_Y in 2:
					var icn =  $ResourcesIcons.duplicate()
					icn.frame = i[1]
					icon_node.add_child(icn)
					icn.global_position = rpos + Vector2(1000*I_X, 700*I_Y)
					icn.global_position += Vector2(0.5,0.5)
			break

func spawn_starting_cities():
	
	var best_wood = null
	var best_stone = null
	var best_coal = null
	
	var wood_spots = Array()
	var stone_spots = Array()
	var coal_spots = Array()
	for i in material_coords:
		if i.z == 0:
			wood_spots.append(Vector2(i.x,i.y))
		elif i.z == 3:
			stone_spots.append(Vector2(i.x,i.y))
		elif i.z == 7:
			coal_spots.append(Vector2(i.x,i.y))
	
	coal_spots.shuffle()
	for i in coal_spots:
		best_coal = Vector2(i.x,i.y)
		break
	
	for i in stone_spots:
		if best_stone == null or abs(i.distance_to(best_coal)-ideal_start_distance) < abs(best_stone.distance_to(best_coal)-ideal_start_distance):
			best_stone = Vector2(i.x,i.y)
	
	for i in wood_spots:
		if best_wood == null or abs(i.distance_to(best_coal)-ideal_start_distance)+abs(i.distance_to(best_stone)-ideal_start_distance) < abs(best_wood.distance_to(best_coal)-ideal_start_distance)+abs(best_wood.distance_to(best_stone)):
			best_wood = Vector2(i.x,i.y)

	for i in coal_spots:
		if best_coal == null or abs(i.distance_to(best_wood)-ideal_start_distance)+abs(i.distance_to(best_stone)-ideal_start_distance) < abs(best_coal.distance_to(best_wood)-ideal_start_distance)+abs(best_coal.distance_to(best_stone)):
			best_coal = Vector2(i.x,i.y)
	
	var best = [best_wood,best_stone,best_coal]
	
	for i in best:
		var ang = randi()
		var pos = null
		while pos == null or $Node/map/ocean_heights.texture.get_image().get_pixelv(pos).r == 0:
			ang = randi()
			pos = i + Vector2(int(cos(ang)*5),int(sin(ang)*3))
		if pos.x > 1000:
			pos.x -= 1000
		elif pos.x < 0:
			pos.x += 1000
		
		if pos.y > 700:
			pos.y -= 700
		elif pos.y < 0:
			pos.y += 700
		
		var town_name = town_names[0]
		town_names.remove_at(0)
		var label_node = Node2D.new()
		$Node/Labels.add_child(label_node)
		var icon_node = Node2D.new()
		$Node/Icons/settlements.add_child(icon_node)
		
		towns.append([town_name,icon_node,pos,[i]])
		
		#print(town_name+":",pos,"     res:",towns[-1][2])
		
		for I_X in 2:
			for I_Y in 2:
				var icn =  $SettlementsIcons.duplicate()
				
				icon_node.add_child(icn)
				icn.global_position = pos + Vector2(1000*I_X, 700*I_Y)
				icn.global_position += Vector2(0.5,0.5)
		
		for I_X in 3:
			for I_Y in 3:
				var lbl =  $Test.duplicate()
				lbl.text = "  "+town_name
				
				label_node.add_child(lbl)
				lbl.global_position = (pos+Vector2(-1000, -700)) + Vector2(1000*I_X, 700*I_Y)
	
	$Node/sun.position.x = best_wood.x - 500




func _process(_delta):
	while done_calculating == false:
		post_ready()
	
	if Stats.map_on:
		player.position = Stats.player_position
		
		$cursor.global_position = Vector2(int(get_global_mouse_position().x), int(get_global_mouse_position().y))
		$cursor.scale = (Vector2(1,1)/camera.zoom.y) * 2
		if Input.is_action_pressed("shift") and is_writing == false and create_labels:
			$cursor.text = "/"
		elif Input.is_action_pressed("rmb"):
			var m_pos = Vector2(int(get_global_mouse_position().x), int(get_global_mouse_position().y)) - Vector2(int(map_node.position.x), int(map_node.position.y))
			while m_pos.x >= 1000:
				m_pos.x -= 1000
			while m_pos.y >= 700:
				m_pos.y -= 700
			
			var height = $Node/map/ocean_heights.texture.get_image().get_pixelv(m_pos).r*0.2
			if height > 0 and $Node/map/ocean_heights.texture.get_image().get_pixelv(m_pos).r > 0:
				height += $Node/map/hills_heights.texture.get_image().get_pixelv(m_pos).r
			height *= 8000
			
			var temperature = $Node/map/temperature.texture.get_image().get_pixelv(m_pos).r - 0.4
			temperature *= 70
			temperature -= height/300
			
			$cursor.text = str(m_pos)
			#$cursor.text = str(m_pos,"   alt:",int(height),"   C´:",int(temperature))
			#$cursor.text = str("  alt:",int(height),"   C´:",int(temperature))
		else:
			$cursor.text = ""
		
		if create_labels:
			edit_labels_func()
		if is_writing == false:
			movement()
		
		scale_labels()
		scale_icons()
		fade_icons()
		
		for i in cursor.get_children():
			i.width = 5 * (1/camera.zoom.x)
		if Stats.landed:
			select_route()
		
		$Node/sun.global_position.y = _get_camera_center().y
		var a = (1-(min_camera_zoom/camera.zoom.y))*10
		$Node/map/clouds.modulate.a = 1-a

		camera.zoom += Vector2(1,1) * (camera_target_zoom-camera.zoom.x)/20
		map_node.position += camera_target_pos
		offset -= camera_target_pos
		camera_target_pos /= 1.05

func movement():
	if Input.is_action_pressed("left"):
		map_node.position.x += camera_speed / camera.zoom.x
		offset.x -= camera_speed / camera.zoom.x
	elif Input.is_action_pressed("right"):
		map_node.position.x -= camera_speed / camera.zoom.x
		offset.x += camera_speed / camera.zoom.x
	
	if map_node.position.x < -1000:
		map_node.position.x = 0
	elif map_node.position.x > 0:
		map_node.position.x = -1000
	
	if Input.is_action_pressed("down"):
		map_node.position.y -= camera_speed / camera.zoom.x
		offset.y += camera_speed / camera.zoom.x
	elif Input.is_action_pressed("up"):
		map_node.position.y += camera_speed / camera.zoom.x
		offset.y -= camera_speed / camera.zoom.x

	if map_node.position.y < -700:
		map_node.position.y = 0
	elif map_node.position.y > 0:
		map_node.position.y = -700
	
	if len(cursor_points) == 1:
		if offset.x > 500:
			offset.x = -500
		elif offset.x < -500:
			offset.x = 500
		if offset.y > 350:
			offset.y = -350
		elif offset.y < -350:
			offset.y = 350


func _input(event : InputEvent) -> void:
	if is_writing:
		if len(txt) == 0:
			for i in labels.get_children():
				i.text = "/"
				
		
		if event is InputEventKey:
			if event.pressed:
				txt += char(event.unicode)
				for i in labels.get_children():
					i.text = txt+"/"
			if Input.is_action_just_pressed("back"):
				txt = txt.left(-1)
				for i in labels.get_children():
					i.text = txt+"/"
		if Input.is_action_just_pressed("confirm"):
			for i in labels.get_children():
				i.text = txt
			labels = null
			txt = ""
			is_writing = false
		elif Input.is_action_just_pressed("rmb") or Input.is_action_just_pressed("lmb") or (Input.is_action_just_pressed("confirm") and len(txt) == 0):
			labels.queue_free()
			labels = null
			txt = ""
			is_writing = false

	else:
		if event is InputEventMouseButton:
			if event.pressed:
				match event.button_index:
					MOUSE_BUTTON_WHEEL_UP:
						if camera_target_zoom < max_camera_zoom:
							camera_target_zoom *= 1.1
							camera_target_pos = -(get_global_mouse_position()-_get_camera_center())/30
						if camera_target_zoom > max_camera_zoom:
							camera_target_zoom = max_camera_zoom
					MOUSE_BUTTON_WHEEL_DOWN:
						if camera_target_zoom > min_camera_zoom:
							camera_target_zoom /= 1.1
							camera_target_pos = (get_global_mouse_position()-_get_camera_center())/30
						if camera_target_zoom < min_camera_zoom:
							camera_target_zoom = min_camera_zoom

func _get_camera_center():
	var vtrans = get_canvas_transform()
	var top_left = -vtrans.get_origin() / vtrans.get_scale()
	var vsize = get_viewport_rect().size
	return top_left + 0.5*vsize/vtrans.get_scale()

func edit_labels_func():
	if Input.is_action_just_pressed("lmb") and Input.is_action_pressed("shift"):
		is_writing = true
		click_pos = Vector2(int(get_global_mouse_position().x), int(get_global_mouse_position().y))
		txt = ""
		var rpos = click_pos + Vector2(-1000, -700)
		
		var label_node = Node2D.new()
		$Node/Labels.add_child(label_node)
		labels = label_node
		label_node.position = Vector2.ZERO
		
		for x in 3:
			for y in 3:
				var lbl =  $Test.duplicate()
				label_node.add_child(lbl)
				lbl.text = txt
				lbl.scale = (Vector2(1,1)/camera.zoom.y) * 2
				lbl.global_position = rpos + Vector2(1000*x, 700*y)

func fade_labels():
	for i in $Node/Labels.get_children():
		for u in i.get_children():
			if (get_global_mouse_position()-(u.size*u.scale.x)/3).distance_to(u.global_position) < (u.size.x*u.scale.x)/4 and is_writing == false and u.modulate.a > 0.1:
				if Input.is_action_pressed("shift"):
					u.modulate.r = 1
					u.modulate.g = 0
					u.modulate.b = 0
					if Input.is_action_just_pressed("rmb"):
						i.queue_free()
				else:
					u.modulate.r = 0
					u.modulate.g = 1
					u.modulate.b = 0
			else:
				u.modulate = Color(1,1,1)
			var cam = ((1/camera.zoom.y) * 2)
			var a = 1-(abs(u.scale.y - cam)*1.5)
			u.modulate.a = a

func fade_icons():
	var a = (1-(min_camera_zoom/camera.zoom.y))*10
	$Node/Icons/resource.modulate.a = a

func scale_labels():
	for i in $Node/Labels.get_children():
		for u in i.get_children():
			u.scale = (Vector2(1,1) * text_scale) * (1/camera.zoom.x)

func scale_icons():
	for i in $Node/Icons.get_children():
		for z in i.get_children():
			for u in z.get_children():
				u.scale = (Vector2(1,1) * icon_scale) * (1/camera.zoom.x)

func show_discovered():
	var num = 0
	
	for i in material_coords:
		for t in towns:
			if t[3].has(Vector2(i.x,i.y)):
				$Node/Icons/resource.get_child(num).visible = true
				break
			else:
				$Node/Icons/resource.get_child(num).visible = false
		num += 1

var done_selecting = false
var calculated = false
var cursor_points = PackedVector2Array()
func select_route():
	var rel_m = get_global_mouse_position()
	rel_m = Vector2(int(rel_m.x),int(rel_m.y))
	
	var last_check = len(cursor_points)
	var scl = (icon_scale * (1/camera.zoom.x))*10
	var m = (get_global_mouse_position()-map_node.position)-Vector2(1000,700)
	if m.x < 0:
		m.x += 1000
	if m.y < 0:
		m.y += 700
	
	var pm = Vector2(int(m.x),int(m.y))
	var in_town = false
	
	if Input.is_action_just_pressed("rmb") and len(cursor_points) > 1:
		done_selecting = false
		calculated = false
		target.visible = false
		cursor_points.remove_at(len(cursor_points)-1)
		for i in cursor.get_children():
			i.remove_point(len(i.points)-1)
	
	for i in towns:
		if Stats.player_position == i[2] and cursor_points.has(i[2]) == false and done_selecting == false:
			cursor_points.append(i[2])
			break
		elif m.distance_to(i[2]+Vector2(0.5,0.5)) < scl:
			i[1].modulate.r = 6
			in_town = true
			if Input.is_action_just_pressed("lmb") and cursor_points.has(i[2]) == false and done_selecting == false:
				done_selecting = true
				var up = Vector2.ZERO
				
				if cursor.get_child(0).points[-1].x-i[2].x > 500:
					up.x += 1000
				elif cursor.get_child(0).points[-1].x-i[2].x < -500:
					up.x -= 1000
				
				if cursor.get_child(0).points[-1].y-i[2].y > 350:
					up.y += 700
				elif cursor.get_child(0).points[-1].y-i[2].y < -350:
					up.y -= 700
					
				cursor_points.append(i[2]+up)
			break
		else:
			i[1].modulate.r = 1
		
		if cursor_points.has(i[2]):
			i[1].modulate.r = 6

	if len(cursor_points) > 0 and Input.is_action_just_pressed("lmb") and in_town == false and cursor_points.has(pm) == false and done_selecting == false:
		cursor_points.append(pm)
	
	if last_check < len(cursor_points) and len(cursor_points) != 0:
		for i in cursor.get_children():
			if in_town or len(cursor_points) == 1:
				i.add_point(cursor_points[-1] + Vector2(0.5,0.5))
			else:
				i.add_point((cursor_points[0]-Vector2(500,350)) + offset + rel_m + Vector2(0,0.5))
	
	if done_selecting and len(cursor_points) != 1 and calculated == false:
		calculated = true
		Stats.player_progress = 0
		Stats.curr_level = calculate_level()
		print((float(len(Stats.curr_level))*Stats.secconds_per_point)/60)
		target.position = cursor_points[-1] - Vector2(1000,700)
		target.visible = true

func calculate_level():
	
	var level_stats = []
	var level_seed = 0
	var hazard_seed = 0
	var points = []
	
	for i in len(cursor_points):
		if i != len(cursor_points)-1:
			var precut = interpolated_line(cursor.get_child(0).points[i], cursor.get_child(0).points[i+1])
			#precut.remove_at(0)
			points.append_array(precut)
	points.remove_at(0)
	points[-1] = cursor_points[-1]
	
	for i in points:
		var value = i
		while value.x > 1000:
			value.x -= 1000
		while value.x < -1000:
			value.x += 1000
		while value.y > 700:
			value.y -= 700
		while value.y < -700:
			value.y += 700
		
		var height = $Node/map/ocean_heights.texture.get_image().get_pixelv(i).r*0.2
		if height > 0 and $Node/map/ocean_heights.texture.get_image().get_pixelv(i).r > 0:
			height += $Node/map/hills_heights.texture.get_image().get_pixelv(i).r
		height *= 8000
		
		var temperature = $Node/map/temperature.texture.get_image().get_pixelv(i).r - 0.4
		temperature *= 70
		temperature -= height/300
		
		var biome = $Node/map/temperature.texture.get_image().get_pixelv(i).r
		
		level_seed += height+temperature+biome
		
		var clouds = $Node/map/clouds.texture.get_image().get_pixelv(i).a
		var light = $Node/map/light.texture.get_image().get_pixelv(i).r
		
		hazard_seed += clouds+light
		
		level_stats.append([i,level_seed,hazard_seed,height,temperature,biome,clouds,light])
	
	return level_stats

func interpolated_line(point_0, point_1):
	var p0 = [point_0.x,point_0.y]
	var p1 = [point_1.x,point_1.y]
	
	var points = []
	var dx = p1[0] - p0[0]
	var dy = p1[1] - p0[1]
	var N = max(abs(dx), abs(dy))
	for i in N + 1:
		var t = float(i) / float(N)
		var point = Vector2(round(lerp(p0[0], p1[0], t)), round(lerp(p0[1], p1[1], t)))
		points.append(point)
	return points
