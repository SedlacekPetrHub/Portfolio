extends CharacterBody2D

var UP = Vector2(0, -1)

var landing = true

func _physics_process(_delta):
	
	if Stats.map_on == false:
	
		for i in $hull_area.get_overlapping_bodies():
			if i != self and Stats.landed == false:
				rotation_degrees += (i.global_position.x-$center_of_mass.global_position.x) / (700)
			
			if Stats.landed == true and i.name == "player" and get_parent().map_script.done_selecting == true:
				get_parent().player.checkmark.visible = true
				if Input.is_action_just_pressed("confirm"):
					Stats.landed = false
					Stats.landing = false
					Stats.rising = true
			else:
				get_parent().player.checkmark.visible = false
		
		rotation_degrees *= 0.99
		
		
		if Stats.landing or Stats.landed:
			velocity.y = 400#(10*(1+(-position.y/1000))) + abs(rotation_degrees)*3
			velocity.x = rotation_degrees*5
		elif Stats.rising:
			velocity.y = -400#(-30*(1+(-position.y/1000))) + abs(rotation_degrees)*2
			velocity.x = rotation_degrees*5
		else:
			velocity.y = -20 + abs(rotation_degrees)*3
			velocity.x = rotation_degrees*15
		move_and_slide()
		visuals()

func visuals():
	$decals/baloon.global_rotation = 0
	
	$decals/left_rope.set_point_position(0,$decals/left_point.position)
	$decals/baloon_left_point.global_position = $decals/baloon/left_point.global_position
	$decals/left_rope.set_point_position(1,$decals/baloon_left_point.position)
	
	$decals/right_rope.set_point_position(0,$decals/right_point.position)
	$decals/baloon_right_point.global_position = $decals/baloon/right_point.global_position
	$decals/right_rope.set_point_position(1,$decals/baloon_right_point.position)


func _on_bottom_area_body_entered(body):
	if body != self and Stats.landed == false and Stats.landing:
		Stats.landed = true
		Stats.landing = false
		Stats.player_progress = 0
		get_parent().map_script.target.visible = false
		get_parent().camera.zoom = Vector2(1.5,1.5)
		get_parent().camera_target_zoom = 1.5
		
		get_parent().map_script.done_selecting = false
		get_parent().map_script.calculated = false
		get_parent().map_script.target.visible = false
		get_parent().map_script.cursor_points.clear()
		for i in get_parent().map_script.cursor.get_children():
			i.clear_points()
