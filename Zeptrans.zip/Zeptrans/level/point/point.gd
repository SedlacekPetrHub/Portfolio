extends Node2D

var width = 400

@onready var tilemap = $TileMap

func _ready():
	var noise = FastNoiseLite.new()
	noise.seed = randi()
	noise.noise_type = 3
	noise.fractal_octaves = 6
	noise.frequency = 0.005
	
	tilemap.clear()
	for x in width:
		var val:float = noise.get_noise_1d(x)
		val += 0.6
		val *= 100
		for h in val:
			tilemap.set_cell(0, Vector2(x-width/2,-h), 0, Vector2(0, 0), 0)
	
	$AnimationPlayer.play("roll")
	$AnimationPlayer.speed_scale = 0.5
