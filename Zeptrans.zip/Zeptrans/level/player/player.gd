extends CharacterBody2D

var UP = Vector2(0, -1)

@onready var checkmark = $Checkmark

var speed = 100
var jump_height = 250

func _process(_delta):
	if Stats.map_on == false:
		if is_on_floor() == false:
			velocity.y += Stats.gravity
	
		if Input.is_action_pressed("left"):
			velocity.x = -speed
			$Sprite.flip_h = true
			$AnimationPlayer.play("walk")
		elif Input.is_action_pressed("right"):
			velocity.x = speed
			$Sprite.flip_h = false
			$AnimationPlayer.play("walk")
		else:
			velocity.x = 0
			$AnimationPlayer.play("idle")
		
		if Input.is_action_just_pressed("up") and is_on_floor():
			velocity.y -= jump_height
	
		move_and_slide()
