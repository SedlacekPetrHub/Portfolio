extends Node

@onready var player = $player
@onready var baloon = $baloon

@onready var map = $UI/map
@onready var map_script = $UI/map/SubViewport/map

@onready var camera = $camera_target/Camera
var max_camera_zoom = 6
var min_camera_zoom = 0.1
var camera_target_zoom = 2

var timer = 0

func _physics_process(_delta):
	
	if Stats.in_city:
		camera.position_smoothing_speed = 5
		if Stats.landed == false:
			camera.zoom = (Vector2(1,1) / $city/landing_spot.global_position.distance_to(baloon.global_position))*700
			if camera.zoom.x > 1.5:
				camera.zoom = Vector2(1.5,1.5)
			$camera_target.global_position = ($city/landing_spot.global_position + baloon.global_position)/2
		else:
			$camera_target.global_position = player.global_position
	else:
		$camera_target.global_position = baloon.global_position
	
	if -baloon.position.y > 1500 and Stats.rising:
		Stats.flying = true
		Stats.rising = false
		Stats.in_city = false
		camera_target_zoom = camera.zoom.x
	
	if Input.is_action_just_pressed("toggle_map"):
		Stats.map_on = !Stats.map_on
		if Stats.map_on:
			map_script.offset *= 0
			map_script.map_node.position = -(Stats.player_position - Vector2(500,350))
	
	if Stats.map_on:
		map.visible = true
	else:
		map.visible = false
		camera.zoom += Vector2(1,1) * (camera_target_zoom-camera.zoom.x)/20
		
		if Stats.flying:
			timer += 1
			if timer >= Stats.secconds_per_point*60:
				timer = 0
				Stats.player_progress += 1
				Stats.player_position = Stats.curr_level[Stats.player_progress][0]
				var point = load("res://level/point/point.tscn").instantiate()
				print(int((float(Stats.player_progress)/len(Stats.curr_level))*100), " %")
				$background.add_child(point)
				for i in $background.get_children():
					i.z_index += 1
			elif Stats.player_progress == len(Stats.curr_level)-1:
				Stats.player_progress = 0
				Stats.player_position = Stats.curr_level[-1][0]
				Stats.flying = false
				Stats.in_city = true
				Stats.landing = true
	
func _input(event : InputEvent) -> void:
	if event is InputEventMouseButton and Stats.map_on == false:
		if event.pressed:
			match event.button_index:
				MOUSE_BUTTON_WHEEL_UP:
					if camera_target_zoom < max_camera_zoom:
						camera_target_zoom *= 1.1
					if camera_target_zoom > max_camera_zoom:
						camera_target_zoom = max_camera_zoom
				MOUSE_BUTTON_WHEEL_DOWN:
					if camera_target_zoom > min_camera_zoom:
						camera_target_zoom /= 1.1
					if camera_target_zoom < min_camera_zoom:
						camera_target_zoom = min_camera_zoom
